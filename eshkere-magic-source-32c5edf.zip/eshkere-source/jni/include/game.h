#pragma once
#include <stdint.h>
#include <sys/types.h>
#include <vector>

// Skeleton ESP: bone slots and the lines connecting them.
constexpr int ESP_BONE_COUNT      = 22;

struct EspBox {
    unsigned long long id;   // stable per-player identity (PlayerManager*), for target stickiness
    float x1, y1, x2, y2;
    float distance;
    // Игрок мёртв. Аим таких не берёт в цель: труп ещё несколько секунд живёт
    // в списке игроков и отдаёт корректные кости, из-за чего прицел уезжал на
    // уже убитого (просьба 19.09). Считаем по двум независимым признакам:
    //   * Oxide.PlayerManager.respawning (bool, 0x208) — «ждать возрождения»;
    //   * здоровье: PlayerManager.vitals (0xC8) -> brS.Entity (0x68)
    //     -> brz.Health (0x98) -> значение (+0x18 или +0x20).
    // Первый в логе 14:55 не срабатывал ни разу (мёртвых 0 при жалобе игрока),
    // поэтому основной признак — здоровье, а оба значения пишутся в лог.
    // Здоровье НЕ в GenericVitals.KQN (0xB8): срез памяти из лога 15:56 показал
    // там ровно 0.0 у всех игроков при честных 100.0 в m_MaxHealth (0x88).
    bool  dead = false;
    float health = -1.f;          // текущее здоровье, -1 = не прочитано
    unsigned health_slot = 0;     // из какого смещения прочитано (0x18 / 0x20)
    // Габариты скелета в метрах — по ним и определяется мёртвый (труп лежит).
    int   death_flag = -1;        // Oxide.PlayerDeathHandler.death: 1/0/-1
    float skel_up = -1.f;         // размах костей по вертикали
    float skel_flat = -1.f;       // наибольший размах по горизонтали
    int   skel_bones = 0;         // сколько костей дали мировую позицию
    bool  respawning = false;     // PlayerManager.respawning (0x208)
    float corners[8][2];
    bool  corner_visible[8];

    // Player name / held weapon (UTF-8, may be empty). Filled from the
    // nicklabel (UI.Text) and FPManager current-weapon chains.
    bool  has_name = false;
    char  name[32] = {};
    bool  has_weapon = false;
    char  weapon[48] = {}; // localized, UTF-8 (Russian names are wider)
    // Sprite ids for the remotely observed equipment rig: head, torso, legs, feet.
    uint8_t armor_icons[4] = {};

    // Team / clan. `ally` is true when this player shares the local player's
    // team name or clan id; `tag` is the clan tag, shown next to the name.
    bool  ally = false;
    bool  has_tag = false;
    char  tag[16] = {};

    // Skeleton (screen-space bone positions), filled when skeleton ESP is enabled.
    bool  has_skeleton;
    bool  bone_valid[ESP_BONE_COUNT];
    float bones[ESP_BONE_COUNT][2];

    // Aim targets (screen-space), always filled when the bone transforms are
    // resolvable — independent of whether skeleton ESP drawing is enabled.
    //   aim_pts[0] = head (skull centre), [1] = neck, [2] = chest (upper spine).
    // aim_valid[i] == false means the corresponding bone could not be read and
    // the caller should fall back to the box estimate.
    bool  aim_valid[3];
    // Where the aim points came from: 0 none, 2 KCC head transform
    // (crouch-aware), 3 feet + pose height (estimate). 1 (хитбокс головы) больше
    // не выставляется: голова берётся по кости, хитбокс убран.
    int   aim_source;
    bool  crouched;
    float aim_pts[3][2];
    // Angular offset of each aim point from the camera forward axis, in
    // degrees (yaw = +right, pitch = +up). Only meaningful when aim_valid[i].
    float aim_yaw[3];
    float aim_pitch[3];
    // Угловая скорость точки прицела вокруг камеры, град/с (+right, +up). Петля
    // аима прибавляет её к своему шагу: без этого при ровном стрее прицел висит
    // за целью на постоянном угле v/k, и его приходилось прятать в задержку.
    // Считается из той же скорости, которой ведётся упреждение, и по той же
    // оси камеры, от которой меряются aim_yaw/aim_pitch.
    float aim_rate_yaw[3] = {};
    float aim_rate_pitch[3] = {};
    // Exact uncompensated bone position for the silent writer. Touch/Memory
    // retain their current angular compensation in aim_yaw/aim_pitch.
    float aim_world[3][3] = {};
    // Horizontal speed (m/s) of the target from the silent motion estimate;
    // 0 when no estimate. Used by aim.cpp to pick the hit zone.
    float aim_speed = 0.f;
    bool  aim_world_valid[3] = {};
    // Бот (враждебный NPC): бокс собран не из игрока, а из маркера — только
    // данные для аима (точка = шея по росту от земли). Оверлей такие боксы
    // не рисует (ботов рисуют маркеры), аим берёт на общих основаниях.
    bool  is_bot = false;
    // Видимость цели от камеры локального игрока (LOS): true = на прямой
    // видимости (нет стены/террейна между камерой и целью), false = за
    // укрытием. Заполняется в esp_get_boxes() через RaycastManager +
    // офф-осевой лучевой зонд AimAssist (hwR.ohe).
    bool  visible = true;

    // ---- Мировой якорь для перепроецирования -------------------------------
    // Кадр, у которого не перечитался список игроков (или сорвалось чтение
    // позиции), повторить ПРОШЛЫЕ экранные координаты не может: они посчитаны
    // прошлой матрицей вида и при любом движении камеры разъезжаются с миром —
    // это и есть жалоба «визуалы плавают по экрану, а не держатся на объектах».
    // Поэтому бокс несёт свою мировую геометрию (ноги, границы тела, мировые
    // кости), и такой кадр считает экран заново текущей матрицей
    // (esp_box_reproject). Матрицы вида у кадра нет — запись не рисуется вовсе:
    // замороженный на экране бокс хуже одной пропавшей.
    bool  anchor_valid = false;
    float anchor_feet[3] = {};      // позиция ног — то, от чего меряется дистанция
    float anchor_bottom_y = 0.0F;   // низ тела (уже с поправкой выбранного пути позиции)
    float anchor_top_y = 0.0F;      // верх тела (ноги + рост, присед учтён)
    float anchor_bone[ESP_BONE_COUNT][3] = {};
    unsigned anchor_bone_ok = 0;    // битовая маска ESP_BONE_COUNT: бит i — кость i валидна
};

// World markers: ore nodes, animals, bots and vehicles, drawn as a small
// labelled pill at the object's screen position. All come from the same
// networked source (Oxide.MineableObject in Mirror's client registry),
// so one struct covers them.
enum EspMarkerKind { ESP_MARKER_ORE = 0, ESP_MARKER_ANIMAL = 1, ESP_MARKER_LOOT = 2, ESP_MARKER_PICKUP = 3, ESP_MARKER_BOT = 4, ESP_MARKER_VEHICLE = 5, ESP_MARKER_SCRAP = 6, ESP_MARKER_TURRET = 7, ESP_MARKER_BACKPACK = 8, ESP_MARKER_SLEEPER = 9, ESP_MARKER_HOUSE = 10, ESP_MARKER_CUPBOARD = 11, ESP_MARKER_PUMPKIN = 12 };
struct EspMarker {
    unsigned long long id = 0;  // marker component pointer; stable across readable frames
    float x = 0.0F, y = 0.0F;   // screen position (top-centre of the pill)
    float distance = 0.0F;      // metres from the local player
    int   kind = ESP_MARKER_ORE;
    // Ore markers carry their own colour (one per resource); when has_color is
    // false the caller picks the colour for that kind.
    bool  has_color = false;
    // Elite crates: the overlay cycles the label colour through the spectrum.
    bool  rainbow = false;
    unsigned char color_rgb[3] = {255, 255, 255};
    char  name[40] = {};        // localized label (UTF-8), may carry a stack size
    // Мировой якорь — ровно та точка, что ушла в экранную проекцию (уже с
    // подъёмом по типу объекта). Нужен перепроецированию на битом кадре: метка
    // тоже не должна прилипать к экрану, пока камера едет.
    bool  world_valid = false;
    float world[3] = {};
};

// Почему привязка к игре не удалась — для диагностики (лог, skel-отчёт).
// GUI тостов привязки не показывает (см. KERNEL.md §6).
enum EspAttachState {
    ESP_ATTACH_OK = 0,
    ESP_ATTACH_NO_PID,
    ESP_ATTACH_NO_LIB,
    ESP_ATTACH_NO_ACCESS,
    ESP_ATTACH_BAD_IMAGE,
};

// package_verified_release may be true only for the exact official release
// applicationId. It permits the old_source-compatible early-loading attach
// before IL2CPP TypeInfo statics are initialized; renamed candidates remain
// strictly image-validated.
bool          esp_init(pid_t pid, bool package_verified_release = false);
void          esp_reset();
EspAttachState esp_attach_state();
// Начало кадра: сброс кэша блоков памяти игры (см. mem_io.h).
void          esp_mem_frame_begin();
// Способ доступа к памяти игры. Выбирается один раз на старте, ДО первого
// bind (экран режима mode_select.h); дальнейший код чтения
// транспорт-агностичен и про режимы не знает.
enum EspMemBackend {
    ESP_MEM_EXTERNAL = 0,   // /proc/<pid>/mem — «Прямое чтение»
    ESP_MEM_FT       = 1,   // сокет драйвера bing-класса — «FT-Драйвер»
    ESP_MEM_RT_DEV   = 2,   // /dev/[A-GNY]{1,6} RT-Dev — «RT-Dev»
    ESP_MEM_RT_HOOK  = 3,   // legacy syscall ioctl hookdd/gynhdd — «RT-Hook»
    ESP_MEM_DITPRO   = 4,   // ditPro 131 KPM syscall transport
};
void          esp_set_mem_backend(int backend);
int           esp_get_mem_backend();
// Измеренная задержка позы цели (aim_predict.h), мс; -1 — оценки ещё нет.
float         esp_aim_delay_ms();
// Какой режим активен: true для любого ядерного транспорта (FT/RT-Dev/RT-Hook/DitPro).
bool          esp_mem_backend_kernel();
// Поиск PID процесса игры через ядерный драйвер (DitPro 131 0x300),
// если прямой обход /proc ограничен или не дал результата.
pid_t         esp_find_kernel_pid(const char* pkg);
// Последняя ошибка транспорта (errno): для тоста «почему привязка не идёт».
int           esp_mem_last_errno();
// Доступ из фонового потока сайлент-аима: строго через выбранный способ
// чтения (g_mem/транспорт), БЕЗ собственного /proc/<pid>/mem — в кернел-
// режимах собственный fd светился в fd-листе чита и не работал при
// закрытом прямом доступе. Чтение идёт мимо кадрового кэша (read_quiet)
// и не мешает рендер-потоку; esp_silent_target проверяет, что игра
// привязана именно к этому pid выбранным транспортом.
bool          esp_silent_target(int pid);
pid_t         esp_target_pid();
bool          esp_silent_read(uint64_t addr, void* out, size_t len);
bool          esp_silent_write(uint64_t addr, const void* in, size_t len);
// Привязка ещё читается? (одно чтение; ловит перезапуск процесса и отобранный доступ)
bool          esp_alive_check();
unsigned long long esp_mem_reads_total();
unsigned long long esp_mem_read_fails_total();
void        esp_set_skeleton_enabled(bool enabled);
// Enable the ore / animal / loot / pickup / vehicle / bot marker scan
// (all off = no work, unless the bot aim feed below is on).
void        esp_set_markers_enabled(bool ore, bool animals, bool loot, bool pickups,
                                    bool vehicles, bool bots, bool scrap = false,
                                    bool turrets = false, bool backpacks = false,
                                    bool sleepers = false, bool house = false,
                                    bool cupboards = false, bool pumpkins = false);
// Типы руды для меток: общий тумблер «Руда» включает их целиком, а эти три
// решают, какие именно камни через него проходят (камень / железо / сера).
// Смена значений перезапускает скан маркеров — снятая галочка гасит метки
// сразу, а не в конце текущего прохода реестра.
void        esp_set_ore_types_enabled(bool stone, bool iron, bool sulfur);
// Упреждение аима: секунды забега вперёд по скорости цели (0 = вести по
// текущему положению кости). Слайдер «Упреждение» на вкладке аима.
void        esp_set_screen_stretch(float factor);
// «Всегда день»: время суток удерживается в полдне (клиентский визуал).
void        esp_set_always_day(bool enabled);
// «Без травы»: отключает GrassEnabled и TreesEnabled (рендерер кустов).
void        esp_set_no_grass(bool enabled);
// Markers further away than this (metres) are dropped. Keeps the screen clean
// on open terrain, where the registry easily holds hundreds of nodes.
void        esp_set_marker_max_distance(float metres);// Markers for the current frame, nearest first. Call after esp_get_boxes():
// it reuses the camera/projection state that call established.
std::vector<EspMarker> esp_get_markers();
bool esp_marker_frame_transient();
// Authoritative death bypasses transient-frame marker retention.
bool esp_marker_confirmed_dead(uint64_t id);

// ---- Кадр ESP: состояние публикации и перепроецирование -------------------
// Матрица вида и камера последнего опубликованного кадра. false — кадр
// битый/пустой: рисовать по нему нечего (см. esp_box_reproject).
bool  esp_frame_projection_valid();
bool  esp_frame_camera_position(float out[3]);
// Перепроецировать мировую геометрию бокса/метки текущим опубликованным кадром.
// false — матрицы нет или запись ушла за кромку: кадр её не рисует.
bool  esp_box_reproject(EspBox& box);
bool  esp_marker_reproject(EspMarker& marker);
// Кадр ИГРЫ (HyperHug...Player.Move: DeltaTime +0x30, Tick +0x34 у локального
// KCC). Оверлей, который пересчитывает камеру и позиции, пока игра не начала
// новый кадр, читает ту же самую камеру и тот же самый мир — то есть рисует
// кадр, которого на экране нет. Отсюда и привязка пересчёта к тику игры.
enum EspGameFrame {
    ESP_GAME_FRAME_SAME      = 0,   // игра нового кадра не начинала
    ESP_GAME_FRAME_ADVANCED  = 1,   // новый кадр игры с прошлого вызова
    ESP_GAME_FRAME_UNKNOWN   = 2,   // тик не читается — работать по своему кадру
};
int   esp_game_frame_tick();
// Сырое значение тика кадра игры (Move.Tick локального игрока). false — тик не
// читается. Для вызывающих, которые сами держат предыдущее значение (темп
// оверлея): так состояние не зависит от того, кто ещё в кадре звал
// esp_game_frame_tick().
bool  esp_game_tick_now(uint32_t& tick);
// Частота кадров игры по переходам тика (сглаженная). 0 — данных нет (тик не
// читается или переходов мало): вызывающий берёт свой запасной темп.
float esp_game_frame_hz();
// Resolve bones (for aim points) even when skeleton ESP drawing is off.
void        esp_set_aim_bones_enabled(bool enabled);
// Temporarily classify verified remote body HitBoxes as Head through the live
// managed KCC data. Values are restored when disabled or despawned.
// Clears tracked remote HitBoxes at scene/process teardown. restore=true only
// while the selected memory transport is still bound to the same game.
// Bot aim feed: world positions of recognised bots, refreshed (scan +
// throttled re-reads) even when bot markers are not drawn — so the aimbot
// keeps working on bots after their ESP is switched off.
// x/y/z — корень маркера (ноги). head_* — точная кость головы модели
// (NPCBrainHumanoid.modelInfo.head), когда её удалось прочитать; иначе аим
// считает голову/шею/грудь от корня и роста. vel_* — своя скорость бота для
// упреждения: до неё цель брала g_aim_lead, оставшийся от последнего игрока.
struct BotAimEnt {
    uint64_t id = 0;
    uint64_t component = 0;
    uint64_t event_handler = 0;
    uint64_t aim_target = 0;
    uint64_t aim_collider = 0;
    float x = 0.f, y = 0.f, z = 0.f;
    bool  head_valid = false;
    float hx = 0.f, hy = 0.f, hz = 0.f;
    bool  neck_valid = false;
    float nx = 0.f, ny = 0.f, nz = 0.f;
    bool  chest_valid = false;
    float cx = 0.f, cy = 0.f, cz = 0.f;
    bool  vel_valid = false;
    float vx = 0.f, vy = 0.f, vz = 0.f;
    // Сколько секунд назад позиция была прочитана. Дальние боты перечитываются
    // раз в 6/15 кадров, и видимый на экране бот за это время успевает уйти.
    float pos_age = 0.f;
};
void esp_set_bot_aim_enabled(bool enabled);
void esp_bot_aim_maintain();
std::vector<BotAimEnt> esp_bot_aim_list();
std::vector<EspBox> esp_get_boxes(int screen_width, int screen_height);
// True when the last box frame ended on a transient memory/resolver failure.
bool        esp_box_frame_transient();

// Players near the local player as of the last esp_get_boxes() call, in all
// directions (360 degrees) — NOT limited to the ones visible on screen.
// Feeds the enemy-counter pill in the overlay.
int         esp_nearby_player_count();
// Number of recognised bots in the current ESP snapshot.
int         esp_nearby_bot_count();

// ---- Пеленги 360°: кто где, включая тех, кого нет в кадре ------------------
// Снимок собирается в том же проходе, что и боксы, но ДО экранной геометрии:
// игрока за спиной на экране нет вовсе (проецирование отказывает по w<=0), а
// стрелка на кольце обязана быть. Угол компасный: 0 = прямо перед камерой,
// дальше +вправо, диапазон ±180. Вертикаль не участвует намеренно — на кольце
// «вверху» значит «впереди», а не «на крыше», зато стрелка не запрыгивает,
// когда игрок задирает прицел к небу.
struct EspBearing {
    unsigned long long id = 0;      // тот же id, что у EspBox (PlayerManager*)
    float yaw = 0.0F;               // градусов от направления камеры, +вправо
    float distance = -1.0F;         // метры от камеры до ног, -1 = не прочитаны
    bool  on_screen = false;        // бокс в этом кадре дорисован
    bool  ally = false;             // свой по группам/кланам
    bool  dead = false;             // respawning или метка трупа
    bool  is_bot = false;
};
// Пеленги последнего опубликованного кадра. Пусто — камеры в этом кадре нет:
// битый кадр не публикуется, иначе стрелки прилипали бы к экрану.
const std::vector<EspBearing>& esp_get_bearings();
// Пеленги стоят лишних чтений (группа игрока, флаг respawn — у отсеянных по
// экрану кадров они больше нигде не считаются), поэтому слой памяти ведёт их
// только пока оверлей действительно рисует стрелки.
void        esp_set_bearings_enabled(bool enabled);

// Диагностика конвейера костей для терминальной команды `benzware skel`
// (см. skeleton_diag.h): печатает в out состояние всех шагов построения
// скелета по первым max_players игрокам. Возврат: 0 — скелеты строятся,
// 2 — ни у одного игрока, 1 — список игроков пуст, -1 — плохие аргументы.
int         esp_skeleton_diag(char* out, size_t cap, int max_players);

// True while the local player is aiming down sights (ADS) with the current
// weapon. Returns false when the state cannot be read (not attached, no
// weapon, menus, etc.), so "aim only while scoped" fails closed.
bool        esp_local_player_is_aiming();
// Номер цепочки, которой отвечен последний esp_local_player_is_aiming():
// 1 активность Aim, 2 isAiming оружия, 0 цепочка не подтвердилась. Нужен,
// чтобы по логу отличать «игрок правда не в прицеле» от сбоя чтения.
int         esp_local_aim_source();

// ---- Автофарм ---------------------------------------------------------------
// Слой памяти только находит узел и говорит, куда смотреть и куда идти; сам
// подход и удары делает контроллер на синтетических тачах в main.cpp.
//
// «Крестик» (hit-streak marker) — объект, который игра сама создаёт на ресурсе
// после первого попадания и уничтожает через 15 секунд простоя. Его координаты
// читаются напрямую из экстеншенов узла (OreHitstreaks.MoW / TreeHitstreaks.MTQ,
// см. game_offsets.h) — именно до них игра меряет дистанцию удара, поэтому
// попадание в крестик засчитывается в серию и даёт бонусный ресурс.
struct FarmTarget {
    unsigned network_id = 0;
    unsigned long long game_base = 0;
    bool magic_supported = false;
    float magic_point_yaw = 0.f;
    bool  valid = false;
    unsigned long long id = 0;    // Mineable-компонент: отдельный узел и blacklist
    int   kind = 0;               // 0 дерево, 1 камень, 2 металл, 3 сера
    float fraction = -1.f;        // остаток ресурса 0..1, -1 = не читается

    // yaw/pitch — ошибка наведения камеры (градусы, +вправо/+вверх) на
    // look_spot: на КРЕСТИК, когда он есть, иначе на центр корпуса узла
    // (первый удар по корпусу создаёт крестик). Камера ведёт крестик, потому
    // что попадание в него обеспечивается наведением штатного луча игры;
    // точка удара aim_* — та же точка, по которой бьём.
    float yaw = 0.f, pitch = 0.f; // ошибка наведения камеры на точку удара
    float aim_dist = 0.f;         // метры по горизонтали до точки удара (крестик)
    float aim_3d = 0.f;           // 3D-метры от глаза до точки удара (от позы
                                  // камеры) — ровно то, что игра сравнивает с
                                  // дальностью удара (FPMelee.ZkX)
    bool  at_spot = false;        // точка удара — крестик (не корпус): по нему
                                  // берутся и подход, и пороги дистанции удара
    bool  look_spot = false;      // камера ведёт крестик (at_spot и луч игры не
                                  // ушёл в посторонний объект). false — ведёт
                                  // центр корпуса: крестика нет либо наведение
                                  // по X уводит луч мимо узла
    // Трим «по факту попадания» (уже добавлен в yaw/pitch выше — поля для
    // диагностики). Это разница двух угловых мер одного и того же крестика:
    // «по камере» и «по точке попадания живого луча игры» — то есть постоянное
    // смещение удара, которое надо держать в наведении (покачивание оружия,
    // отдача, смещение старта луча). Ограничен ±2° и учится только в покое, так
    // что камерой не рулит; живёт между крестиками и узлами как свойство оружия.
    bool  aim_fix_valid = false;
    float aim_fix_yaw = 0.f;      // трим по yaw (градусы, +вправо)
    float aim_fix_pitch = 0.f;    // и по pitch (градусы, +вверх)

    // Дальность удара текущего орудия, прочитанная из игры: FPMelee.m_MaxReach +
    // FPMelee.hitRadius — те самые 3D-метры от камеры, внутри которых
    // FPMelee.ZkX засчитывает удар (снаружи играет On_Woosh). 0 = неизвестно
    // (в руках не ближнее орудие либо чтение не удалось) — тогда контроллер
    // работает по своим эмпирическим порогам.
    float melee_reach = 0.f;
    float melee_ray = 0.f;        // RaycastManager.m_RayLength — длина луча взаимодействия

    // Состояние крестика.
    bool  ext_found = false;      // найден ли сам экстеншен крестика на узле
    bool  has_spot = false;       // X прочитан из памяти игры
    bool  spot_front = false;     // X с нашей стороны узла (диагностика):
                                  // точка подхода теперь всегда перед X, но по
                                  // этому флагу видно, что бот обходит узел
    int   spot_source = 0;        // 1 маркер руды, 2 точка дерева MTQ, 3 декаль дерева
    int   streak = 0;             // hitstreakIndex / MTz: сколько подряд попали в X

    // Куда идти: точка подхода перед крестиком (или перед узлом, если X нет).
    float walk_yaw = 0.f;         // градусы от оси камеры (+вправо)
    float walk_dist = 0.f;        // метры до точки подхода
    float node_dist = 0.f;        // метры по горизонтали до самого узла

    // Орудие в руках и состояние узла — значения из самой игры (дамп 62a8534:
    // FPTool.m_ToolPurposes, FPMelee.m_TimeBetweenAttacks/pauseAfterAttack,
    // MineableObject.m_CurrentHealth/m_MaxHealth/m_Experience).
    int   tool_purposes = 0;      // флаги ToolPurpose (1 дерево, 2 камень, 4 животные); 0 = неизвестно
    float attack_period = 0.f;    // секунд между ударами этого орудия; 0 = неизвестно
    bool  continuous_tool = false; // бензопила / бур (отбойный молоток): непрерывное зажатие атаки
    float node_health = -1.f;     // текущее здоровье цели
    float node_health_max = -1.f; // его же максимум (для процентов)
    int   node_experience = 0;    // сколько опыта даёт узел

    // Луч прицела: результат тех же лучей RaycastManager, из которых игра берёт
    // distance для засчёта удара (Gum.RaycastData/AimRaycast -> GKo.RaycastHit).
    // ray_blocked — луч упёрся заметно раньше нашей точки прицела, то есть узел
    // перекрыт и удар уйдёт в перекрытие: махать в такой ситуации впустую.
    bool  ray_valid = false;
    float ray_distance = 0.f;
    bool  ray_blocked = false;
    // Луч прицела упёрся в САМ узел (его коллайдер/GameObject), просто раньше
    // точки прицела: у камня прицел стоит внутри породы. Это не перекрытие —
    // игра засчитывает удар по distance этого же луча, поэтому ray_blocked при
    // ray_self снимается. Флаг наружу отдаём, чтобы контроллер писал в лог,
    // когда именно сработала эта ветка (иначе её не отличить от «луча нет»).
    bool  ray_self = false;
    // Луч игры упёрся в ПОСТОРОННИЙ объект (постройка, чужой камень, склон) —
    // не в текущий узел, БЕЗ учёта дистанции до точки прицела. Удар в такую
    // линию уходит в чужую геометрию (урон своей постройке у места фарма),
    // поэтому контроллер не машет вовсе, пока луч не очистится или не попадёт
    // в сам узел; упор в постройку теперь сразу идёт в обход/чёрный список.
    bool  ray_foreign = false;
    // Какая проверка признала попадание «своим»: 0 — не признала (или проверка не
    // запускалась), 1 — коллайдер крестика руды (OREHS_COLLIDER), 2 — GameObject
    // узла совпал с GameObject попадания, 3 — попадание внутрь поддерева деталей
    // узла, 4 — руда без крестика, у которой луч остановился в пределах
    // дальности удара (страховка: пивот руды внутри породы, прицел по нему луч
    // не подтверждает, а удар по такому лучу игра засчитывает). Нужна в логе:
    // по ней видно, работает ли послабление на устройстве.
    int   ray_self_why = 0;
    // Якорь точки удара руды (MineableObject.LXX, 0xC8): мировая позиция и
    // дистанция от неё до точки попадания луча. Пишется только для руды и только
    // на кадрах, где луч выглядел перекрытым, — это замер «стоит ли якорь на
    // поверхности камня» (0.0x м) или это мусор (десятки метров).
    bool  ore_anchor_valid = false;
    float ore_anchor_x = 0.f, ore_anchor_y = 0.f, ore_anchor_z = 0.f;
    float ore_anchor_to_ray = -1.f;
    // Куда луч игры упёрся на самом деле (RaycastHit.m_Point) и нормаль
    // поверхности там (m_Normal). ray_point_valid = false, когда координаты не
    // прочитались. По расхождению с точкой прицела видно, стоит ли прицел на
    // коллайдере: у крестика на дереве декаль сдвинута на 0.25 м от коры, и
    // прицел «в воздух» рядом со стволом оставляет луч без попадания — удар
    // при этом не засчитывается вовсе (FPMelee.ZkX играет On_Woosh).
    bool  ray_point_valid = false;
    float ray_px = 0.f, ray_py = 0.f, ray_pz = 0.f;
    float ray_nx = 0.f, ray_ny = 0.f, ray_nz = 0.f;
    // Указатели для пина крестика (esp_farm_cross_pin в game.cpp). Пин
    // автофармом БОЛЬШЕ НЕ ИСПОЛЬЗУЕТСЯ: запись трансформа маркера на живой
    // сборке перестала проходить, удары идут наведением по крестику. Поля
    // заполняются как раньше — по ним видно, жив ли маркер, — и нужны, если
    // пин когда-нибудь вернём.
    unsigned long long cross_ext = 0;              // MineableObjectExtension дерева (сегмент MTQ/MTu — проверка серии)
    unsigned long long cross_node_transform = 0;   // нативный трансформ узла (дерево: world->local)
    unsigned long long cross_marker_transform = 0; // нативный трансформ живого маркера руды (его позицию читает os())
    unsigned long long cross_mark_transform = 0;   // нативный трансформ декали дерева (визуал X)
    // Обёртки GuI<GKo> — живой луч прицела игры: пин читает из него точку,
    // куда реально падает удар (GKo.RaycastHit.m_Point).
    unsigned long long ray_wrapper_primary = 0, ray_wrapper_fallback = 0;

    // Сколько секунд осталось жить крестику (руда — из 15, дерево — из своего
    // lifetime). -1 = неизвестно; 0 = вот-вот потухнет.
    float spot_life = -1.f;

    // Проекция точки прицела на экран — для метки «куда бьёт бот».
    bool  on_screen = false;
    float sx = 0.f, sy = 0.f;

    // Мировые координаты точки прицела и пивота узла. В лог автофарма они
    // идут только в строках EV, но без них геометрию удара не разобрать:
    // насколько прицел отстоит от ствола, попал ли луч игры в ту же точку.
    float aim_x = 0.f, aim_y = 0.f, aim_z = 0.f;
    float node_x = 0.f, node_y = 0.f, node_z = 0.f;
};
// Профиль одного вызова esp_farm_get_target: где именно ушёл кадр автофарма и
// сколько syscall'ов чтения/записи память игры на это потребовала. Нужен для
// разбора лага «фарм съел кадр»: сама стадия в логе видна, а её состав — нет.
// total_ms включает всё, что делает вызов (в т.ч. участки без собственного
// таймера: чёрный список, позиции узлов); суммы участков к нему не обязаны
// сходиться в точности — подтаймеры нужны, чтобы найти виновника, а не свести
// баланс.
// Какие ресурсы добывать: bit0 дерево, bit1 камень, bit2 металл, bit3 сера.
// 0 выключает скан целиком (никакой лишней работы в кадре).
void        esp_farm_set_resources(unsigned mask);
// Радиус поиска узлов в метрах (зажимается в 10..300).
void        esp_farm_set_range(float meters);
// Ближайший подходящий узел по состоянию последнего esp_get_boxes() (нужна
// его камера).
bool        esp_farm_get_target(FarmTarget& out, unsigned long long preferred_id = 0);
// Separate geometry path: the player's current aim ray does not choose or
// invalidate the harvesting point. The companion performs its own raycast.
bool        esp_farm_get_magic_target(FarmTarget& out, unsigned long long preferred_id = 0);
// Пин крестика: телепортировать крестик текущего узла в точку, куда реально
// падает удар (живой луч прицела игры). Дерево — переписывается сегмент
// MTQ/MTu (проверка серии), руда — мировая позиция маркера (os()). Работает
// из фонового потока, пока включён; включать каждый кадр (обновляет точку и
// пересозданные маркеры), выключать при смене узла/паузе.
// ВНИМАНИЕ: автофарм больше не включает пин — он перешёл на наведение по
// крестику (запись трансформа маркера перестала доходить). Вызывать может
// только тот, кто снова захочет этот механизм; поток стартует при первом
// включении.
bool        esp_farm_cross_pin(const FarmTarget& target, bool enabled);
// false — последний цикл пина не смог записаться в память игры (сбой
// транспорта/раскладки). Удары это не блокирует: контроллер переподключает
// пин через пару секунд.
bool        esp_farm_cross_healthy();
// Сдаться на узле (недостижим / застряли) на `seconds`.
void        esp_farm_blacklist(unsigned long long id, float seconds);
// Почему последний esp_farm_get_target() ничего не вернул + сколько узлов
// насчитал последний скан реестра. Причины: 0 ок, 1 фарм выключен,
// 2 кадр не опубликован (нет камеры/позиции), 3 в реестре нет подходящих
// узлов, 4 узлы есть, но все вне радиуса / в чёрном списке, 5 поза камеры
// не читается (не посчитать углы), 6 ближайшие узлы не берутся текущим
// орудием, 7 выбранный узел умер (класс компонента сменился — память уже
// переиспользована, см. проверку живости в esp_farm_get_target).
void        esp_farm_debug(int& nodes_cached, int& idle_reason);
// Что умеет орудие в руках и какие умения запросили отброшенные узлы (флаги
// ToolPurpose). need != 0 при reason == 6 — «ближайший узел нечем взять».
void        esp_farm_tool_info(int& purposes_have, int& purposes_need);
// Сырые поля сегмента крестика у дерева (SPOT_A = точка на коре, SPOT_B = конец
// сегмента) и причина, по которой SPOT_A не стал точкой прицела:
// 0 — принят, 1 — не конечен, 2 — не прошёл проверку «точка на узле»,
// 3 — не читали вовсе (экстеншен не тот / крестика нет). len = |A-B|, -1 если
// не считалась. Нужны в логе автофарма: по ним видно, пусты ли поля в памяти
// или значения есть, но их отвергает проверка.
void        esp_farm_spot_raw(float& ax, float& ay, float& az, float& bx, float& by, float& bz,
                              int& why, float& len);
// X-ray: камера не рисует всё ближе `meters` (запись near clip plane).
// 0 выключает и восстанавливает исходное значение. Диапазон 0..50 м.
void        esp_set_xray(float meters);

// Vertical field of view (degrees) of the game camera as last read by
// esp_get_boxes(). 0 if unknown.
float       esp_camera_fov_deg();

// Absolute camera orientation (degrees; yaw around world up, pitch +up) as of
// the last esp_get_boxes(). Returns false if no source is readable at all.
// Источники: поза камеры, ось выстрела, а если ни одно не читается — базис из
// матрицы вида этого кадра. Это источник ФАРМА (медленный доворот по экранной
// метке): базис отстаёт на кадр, и аимботу он не отдаётся — у аима своя
// функция esp_aim_camera_angles().
bool        esp_camera_angles(float& yaw_deg, float& pitch_deg);
// Углы камеры для аима: ТОЛЬКО поза камеры или ось выстрела. false = настоящей
// оси нет, вести цель можно только вслепую запасным коэффициентом (так аим и
// вёл её в сборке без правок автофарма). Базис из матрицы вида сюда попасть не
// может: по нему gain выучивался со сменой знака, и аим дёргался (лог 15.09).
bool        esp_aim_camera_angles(float& yaw_deg, float& pitch_deg);
// Углы камеры БЕЗ оси выстрела: поза камеры (Transform) или, если её нет,
// базис из матрицы вида. Нужны сайленту с перехватом сеттера: пока перехват
// стоит, ось выстрела — наша же запись, и мерить по ней нельзя (получится
// наше же направление, а не то, куда смотрит игрок).
// Diagnostic: bit 0 camera pose known, bit 1 reserved (never set), bit 2 firing
// reference in use. See esp_camera_state() in game.cpp.
int         esp_camera_state();

// Чувствительность взгляда из настроек клиента (MouseLook.m_Sensitivity).
// Это тот самый множитель, которым игра превращает накопленный сдвиг касания в
// поворот камеры, поэтому град/px пропорционален ему: аим обязан брать
// коэффициент отсюда, а не из зашитого числа, иначе при своей чувствительности
// игрока он либо не доводит цель, либо перелетает её.
// false — прочитать не удалось (нет привязки, нет локального игрока/мыши):
// вызывающий берёт запасное значение.
bool        esp_read_look_sensitivity(float& out);

// Позиция глаза локального игрока в мире — та же точка, от которой меряются
// углы прицела (PlayerEventHandler.LookDirection из KCC, а если её нет — поза
// камеры). Логу автофарма нужна, чтобы сравнивать команды стика с тем, куда
// персонаж пошёл на самом деле. false = поза в этом кадре не прочитана.
bool        esp_local_eye_position(float& x, float& y, float& z);

// ---- Мемори-аим: прицел ведётся записью в память игры ----------------------
//
// Тач-аим крутит камеру синтетическим пальцем (uinput). Мемори-аим пишет прямо
// в память игры, поэтому не зависит от инъекции касаний: работает там, где
// /dev/uinput занят, перехвачен или его нет вовсе.
//
// Оба режима пишут в тот объект, которым игра сама вертит камерой
// (Oxide.MouseLook; PlayerManager.mouseLook, +0x70):
//
//   * «память»  — пишем ввод взгляда в то же поле, куда игра кладёт сдвиг
//     касания за кадр (+0x88, Vector2). Поворот дальше делает САМА игра своим
//     Update: теми же пределами углов, тем же KCC, той же отдачей. Камера
//     едет ровно как от настоящего свайпа — только без пальца.
//
//   * «сайлент» — пишем ось выстрела (PlayerEventHandler.LookDirection):
//     вдоль неё FPHitscan пускает луч попадания. Камера стоит на месте, в цель
//     уходит только выстрел.
//
// Единицы ввода MouseLook: игра умножает значение поля на m_Sensitivity и
// получает ГРАДУСЫ. Видно в MouseLook.ZJo (libil2cpp.so, RVA 0x64e312c — 11989,
// в 11991 RVA съехал, смещения полей те же):
// прочитанное по +0x88 множится на m_Sensitivity (+0x34) и складывается с
// углами взгляда (+0x4C тангаж, +0x50 рысканье), которые тут же зажимаются
// пределами m_DefaultLookLimits (+0x38, Vector2 min/max) и оборачиваются по
// 360. Значит «градус на единицу ввода» = m_Sensitivity ровно, и переводить
// градусы в единицы аиму больше нечем.

// Параметры ввода взгляда у локального игрока:
//   deg_per_unit — сколько градусов даёт одна единица поля ввода (= m_Sensitivity);
//   invert_y     — инверсия вертикали (m_Invert): знак вертикальной оси другой;
//   gyro         — гироскоп включён: игру НЕ обнуляет поле ввода, а ПРИБАВЛЯЕТ
//                  к нему своё, поэтому записанное может сложиться с её вводом.
// false — объект в этом кадре недоступен (нет привязки, нет локального игрока).
bool esp_mem_aim_look_params(float& deg_per_unit, bool& invert_y, bool& gyro);
// Накопитель углов камеры (MouseLook, +0x4C/+0x50) — единственное место, куда
// имеет смысл писать поворот. Почему не поле ввода взгляда (+0x88): ZJo
// сначала зовёт ZJX, а тот перезаписывает +0x88 вводом касания
// (str d0, [x19, #0x88], файл libil2cpp.so 0x64e0364), и только потом ZJo
// читает это поле. Запись между кадрами игры стирается гарантированно.
// С накопителем иначе: ZJo делает angles = clamp(angles + input * sens)
// (ldur d1,[x19,#0x4c] -> fadd -> stur d0,[x19,#0x4c], файл 0x64df2b8), то
// есть наше значение — база, к которой игра прибавляет свой ввод (ноль, если
// экран не трогают) и клампит пределом обзора.
//
// Единицы — градусы, и это же убирает всю возню с коэффициентом: никакой
// m_Sensitivity для перевода не нужен.
//   x_deg — rotationX камеры: в Unity это «наклон вниз», то есть
//           ОТРИЦАТЕЛЬНОЕ возвышение (смотреть вверх = уменьшать);
//   y_deg — rotationY: рысканье, вправо — больше.
bool esp_mem_aim_read_angles(float& x_deg, float& y_deg);
bool esp_mem_aim_write_angles(float x_deg, float y_deg);

// Метка выстрела: время последнего попадания (PlayerEventHandler.LastLocalHitTime,
// +0x178 -> +0x20). FPHitscan.ZDW пишет его после каждого выстрела, поэтому по
// изменению значения видно, что выстрел был — и что в этот момент лежало в оси.
bool esp_mem_aim_last_shot(float& time_sec);

// Ось выстрела (PlayerEventHandler.LookDirection) — нормированный вектор,
// вдоль которого игра пускает луч попадания. Читать её приходится и для
// записи: игру пишет туда forward камеры каждый кадр, поэтому доворачивать
// нужно ТО, что там лежит сейчас, а не абсолютный угол.
bool esp_mem_aim_read_fire_dir(float& x, float& y, float& z);
// Записать ось выстрела. Вектор нормируется здесь: игра множает его на
// дальность луча. false — ось не нашлась (нет игрока/хендлера/привязки).
bool esp_mem_aim_write_fire_dir(float x, float y, float z);

// Publish a fully validated local-player/LookDirection snapshot to the
// independent high-frequency silent writer. `aim` is the exact world-space bone point.
bool esp_silent_publish(uint64_t target, const float aim[3]);
// Silent requests object-data No Spread while the user keeps silent mode enabled,
// independently of whether a target is currently inside the aim FOV.
bool esp_silent_wants_no_spread();

// ---- Фрикам ---------------------------------------------------------------
// Камера отделяется от тела и летает сквозь стены: пишем локальную позицию
// трансформа камеры, игра сама разворачивает её в мировую каждый кадр (подробно
// — в game.cpp, раздел «Фрикам»). Тело при этом остаётся на месте, поэтому
// для сервера ничего не меняется: это только обзор со стороны.
//
// esp_freecam_set(true) запоминает текущую позицию камеры, false — возвращает
// её на место (и по выходу из чита это делается само).
bool esp_freecam_set(bool on);
bool esp_freecam_active();
// Почему фрикам не включился (для меню): 0 порядок, 1 нет камеры,
// 2 нет трансформа, 3 массивы Transform не читаются, 4 мировая позиция
// разошлась с той, что знает ESP (расхождение в метрах — во втором аргументе).
void esp_freecam_diag(int& code, float& dist);
// Сдвинуть камеру на метры: вперёд/назад вдоль взгляда (без наклона), вправо
// и вверх по мировой вертикали.
bool esp_freecam_move(float forward, float right, float up);
// Повернуть камеру: yaw вправо, pitch вверх (градусы)
bool esp_freecam_look(float yaw_delta, float pitch_delta);

// Адрес, по которому загружен libil2cpp.so в процессы игры (0 — ещё не
// привязались).
