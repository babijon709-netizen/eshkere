#pragma once
// Мелкие помощники гуи: мат, тапы по прямоугольникам, анимации.
// Вынесено из main.cpp — используют меню, виджеты, тосты и ESP-оверлей.

#include <cmath>
#include <cfloat>
#include "imgui.h"
#include "imgui_internal.h"   // ImClamp / ImMax / ImMin
#include "widgets.h"          // g_win.closing: лок тапов, пока окно улетает

inline float Lerpf(float a, float b, float t)   { return a + (b - a) * t; }
inline float Clamp01(float t)                    { return t < 0.f ? 0.f : t > 1.f ? 1.f : t; }
inline float EaseOut3(float t)                   { float i = 1 - t; return 1 - i * i * i; }
inline float EaseInOut(float t)                  { return t * t * (3 - 2 * t); }

// Scissor rectangles only discard GPU pixels. AddRect/AddCircle still build
// geometry on the CPU, even for rows far outside a scrolled viewport.
// Keep a small fringe for AA/shadows and check the actual draw-list clip (the
// content area may be smaller than ImGui's window clip).
inline bool DrawRectVisible(const ImDrawList* dl, ImVec2 min, ImVec2 max) {
    const ImVec2 lo = dl->GetClipRectMin(), hi = dl->GetClipRectMax();
    return lo.x < hi.x && lo.y < hi.y &&
           max.x + 2.f > lo.x && min.x - 2.f < hi.x &&
           max.y + 2.f > lo.y && min.y - 2.f < hi.y;
}

// Layout-only estimate: probing CalcTextSizeA at each candidate size in
// ImGui 1.92 creates/rasterizes a separate baked font for every trial size.
// Measure once at the current size; only the final chosen size is baked by
// the real draw call. Callers leave a small margin for hinting differences.
inline ImVec2 MeasureUiTextScaled(const char* text, float size) {
    const float base = ImGui::GetFontSize();
    ImVec2 measured = ImGui::GetFont()->CalcTextSizeA(base, FLT_MAX, 0.f, text);
    const float scale = size / base;
    return {measured.x * scale, measured.y * scale};
}


// Разность углов, приведённая к (-180, 180].
//
// Только арифметикой, БЕЗ циклов «пока больше 180 — вычесть 360»: угол идёт из
// памяти игры и иногда бывает мусорным. От мусорного значения вычитание 360
// ничего не меняет (у float на масштабе 1e38 шаг больше 1e30, у бесконечности
// тем более), и такой цикл не кончается никогда. Ровно это и висело на
// устройстве: лог benzware_aim.log от 17.09, кадр 5695, стадия «выбор цели» —
// 255 с без единого кадра, игра при этом работала (залип поток отрисовки, из
// которого рисуется оверлей). Здесь одна формула и проверка на конечность;
// все места в аиме и фарме зовут её.
inline float WrapDeg180(float d) {
    if (!std::isfinite(d)) return 0.f;
    // Разница двух настоящих углов не шире пары оборотов. Всё, что шире, —
    // мусор из памяти, и приводить его нечего: на масштабе 1e38 шаг float
    // больше 1e30, поэтому делением остаток всё равно не получить. Для мусора
    // честный ответ — ноль (поправки нет), а не огромное число.
    if (!(d > -1e6f && d < 1e6f)) return 0.f;
    if (d > -180.f && d <= 180.f) return d;
    return d - 360.f * std::floor((d + 180.f) / 360.f);
}



inline bool WasTappedHere() {
    if (g_win.closing) return false; // улетающее в пилюлю окно тапов не принимает
    const auto& io = ImGui::GetIO();
    if (!io.MouseReleased[0]) return false;
    auto min = ImGui::GetItemRectMin();
    auto max = ImGui::GetItemRectMax();
    // Строки контента существуют и за пределами видимой области (скролл),
    // поэтому нажатие засчитывается только по видимой (не обрезанной клипом)
    // части строки. Без этого тап по нижней панели вкладок «проваливается»
    // в невидимую строку под ней и включает её функцию.
    {
        ImVec2 clMin = ImGui::GetWindowDrawList()->GetClipRectMin();
        ImVec2 clMax = ImGui::GetWindowDrawList()->GetClipRectMax();
        min.x = ImMax(min.x, clMin.x); min.y = ImMax(min.y, clMin.y);
        max.x = ImMin(max.x, clMax.x); max.y = ImMin(max.y, clMax.y);
        if (min.x >= max.x || min.y >= max.y) return false;
    }
    auto cp  = io.MouseClickedPos[0];
    auto mp  = io.MousePos;
    bool started = cp.x >= min.x && cp.x <= max.x && cp.y >= min.y && cp.y <= max.y;
    bool ended   = mp.x >= min.x - 12.f && mp.x <= max.x + 12.f && mp.y >= min.y - 12.f && mp.y <= max.y + 12.f;
    float dx = mp.x - cp.x, dy = mp.y - cp.y;
    return started && ended && (dx * dx + dy * dy) <= 30.f * 30.f;
}

// Тап по прямоугольнику без виджета ImGui. Нужен там, где гуи рисуется до окна
// меню (стартовый выбор версии игры): ImGui-виджет в этот момент не попадает
// ни в одно окно, ImGui кладёт его в своё служебное «Debug##Default» — и тап не
// срабатывает, и на экране появляется лишнее окно «Debug». Условия те же, что у
// WasTappedHere: палец опущен внутри, отпущен рядом, сдвиг не больше 30 px.
inline bool TapInRect(ImVec2 a, ImVec2 b) {
    const auto& io = ImGui::GetIO();
    if (!io.MouseReleased[0]) return false;
    const ImVec2 cp = io.MouseClickedPos[0];
    const ImVec2 mp = io.MousePos;
    const bool started = cp.x >= a.x && cp.x <= b.x && cp.y >= a.y && cp.y <= b.y;
    const bool ended   = mp.x >= a.x - 12.f && mp.x <= b.x + 12.f &&
                         mp.y >= a.y - 12.f && mp.y <= b.y + 12.f;
    const float tdx = mp.x - cp.x, tdy = mp.y - cp.y;
    return started && ended && (tdx * tdx + tdy * tdy) <= 30.f * 30.f;
}

// Точка внутри текущего клип-прямоугольника окна? Ручные обработчики кликов
// (карточки конфигов, цветные точки и т.п.) обязаны проверять это, иначе тап
// по нижней панели вкладок «проваливается» в прокрученную за неё строку.
inline bool PtInClip(ImVec2 p) {
    auto* dl = ImGui::GetWindowDrawList();
    ImVec2 mn = dl->GetClipRectMin(), mx = dl->GetClipRectMax();
    return p.x >= mn.x && p.x <= mx.x && p.y >= mn.y && p.y <= mx.y;
}

static void SpringTick(float& pos, float& vel, float target, float dt) {
    static constexpr float kStiffness = 180.f;
    static constexpr float kDamping   = 26.f;
    static constexpr float kPosTol    = 0.3f;
    static constexpr float kVelTol    = 1.f;
    float force = kStiffness * (target - pos) - kDamping * vel;
    vel += force * dt;
    pos += vel * dt;
    if (fabsf(target - pos) < kPosTol && fabsf(vel) < kVelTol) { pos = target; vel = 0.f; }
}

static void Tick(float& a, bool v, float dt, float spd = 10.f) {
    if (dt > 0.032f) dt = 0.032f;
    a += (float(v) - a) * spd * dt;
    if (!v && a < .002f) a = 0.f;
    if (v && a > .998f) a = 1.f;
}

inline ImU32 ColU32(const ImVec4& c) {
    return IM_COL32((int)(c.x * 255), (int)(c.y * 255), (int)(c.z * 255), (int)(c.w * 255));
}

inline bool TickSlideAnim(float& anim, float& vel, bool closing, float dt) {
    if (dt > 0.032f) dt = 0.032f;
    const float stiff = 120.f, damp = 22.f;
    if (!closing) {
        float acc = (1.f - anim) * stiff - vel * damp;
        vel  += acc * dt;
        anim += vel * dt;
        if (anim >= 0.9998f) { anim = 1.f; vel = 0.f; }
        anim = ImClamp(anim, 0.f, 1.f);
        return true;
    } else {
        float acc = (0.f - anim) * stiff - vel * damp;
        vel  += acc * dt;
        anim += vel * dt;
        if (anim <= 0.001f) { anim = 0.f; vel = 0.f; return false; }
        anim = ImClamp(anim, 0.f, 1.f);
        return true;
    }
}
