#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
ndk_dir="${1:-${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}}"
if [[ ! -x "$ndk_dir/ndk-build" ]]; then
    echo 'Usage: ./build.sh /absolute/path/to/android-ndk-r26d' >&2
    exit 2
fi
"$ndk_dir/ndk-build" NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk \
    NDK_APPLICATION_MK=jni/Application.mk -j"${JOBS:-4}"
