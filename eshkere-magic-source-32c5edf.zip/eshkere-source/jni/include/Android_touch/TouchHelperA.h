#pragma once

bool Touch_Init(int w, int h, uint32_t orientation_, bool readOnly);
void UpdateScreenData(int w, int h, uint32_t orientation_);

void Touch_Close();
// Аварийное снятие EVIOCGRAB и UI_DEV_DESTROY без join и без аллокаций —
// безопасно из обработчика сигналов и дедлайн-выхода (не перехватить только
// SIGKILL и SIGSTOP).
void Touch_EmergencyRelease();
void Touch_Down(float x, float y);
void Touch_Move(float x, float y);
void Touch_Up();
// Touch-controller units per screen pixel (>= 1 when the digitizer is finer
// than the display). The synthetic finger can only stop on that grid.
float Touch_DeviceUnitsPerPixel();

// Extra synthetic fingers for the auto-farm (0 = move joystick, 1 = look,
// 2 = tap). Separate uinput slots, so they can act at the same time as the
// aimbot finger driven by Touch_Down/Touch_Move/Touch_Up.
void Touch_Down_N(int finger, float x, float y);
void Touch_Up_N(int finger);
// True when synthetic touches actually reach the game (uinput device was
// created). False in read-only fallback mode — everything that injects
// touches (aimbot, auto-farm) silently does nothing then.
bool Touch_CanInject();
bool Touch_IsInitialized();
bool Touch_TryUpgradeInject();
void Touch_FrameStep();

// Диагностика: сколько раз Upload() собрал пакет синтетического тача, сколько
// миллисекунд на это ушло суммарно и сколько вызовов обошлось без отправки
// (пакет был тот же, что уже ушёл в uinput). Счётчики накопительные, хозяин
// цикла оверлея снимает их раз в кадр и считает разницу — по ним видно, сколько
// лага приносит инъекция касаний, а не чтение памяти игры.
void Touch_UploadStats(unsigned long long& calls, double& ms, unsigned long long& skipped);
// Касания внутри прямоугольника (в координатах ImGui, то есть в пикселях
// оверлея) не уходят в игру: их забирает оверлей. on=false — выключить.
void Touch_BlockRect(bool on, float x0, float y0, float x1, float y1);
// Дополнительные прямоугольные зоны блокировки (окно меню, пилюля HUD,
// плавающие кнопки, модальные шторки/поповеры). Обновляются каждый кадр.
void Touch_ClearExtraBlockRects();
void Touch_AddBlockRect(float x0, float y0, float x1, float y1);
// Несколько круглых зон для органов управления фрикама. Блокируется только
// касание, НАЧАВШЕЕСЯ внутри одного из кругов; кнопки игры снаружи работают.
void Touch_BlockCircles(bool on, const float* xs, const float* ys,
                        const float* radii, int count);
// Снимок активных НАСТОЯЩИХ пальцев для органов управления оверлея (фрикам:
// джойстик и обзор держат РАЗНЫЕ пальцы одновременно, а ImGui MousePos видит
// только последний). Координаты — пиксели оверлея, та же система, что у
// io.MousePos. Синтетические пальцы аима/фарма сюда не попадают. Возвращает
// число записанных касаний (до maxCount). Потокобезопасно.
int Touch_GetActive(float* xs, float* ys, int* ids, int maxCount);
