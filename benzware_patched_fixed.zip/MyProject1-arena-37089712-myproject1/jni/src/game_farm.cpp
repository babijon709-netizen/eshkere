#include "game.h"
#include "game_internal.h"
#include "game_offsets_active.h"   // оффсеты (go_active)
#include "lang.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>
#include <unordered_map>
#include <vector>

using namespace go_active;

// ============================== Auto-farm ====================================
//
// Finds the nearest tree / stone / iron / sulfur node in Mirror's registry and
// reports where it is relative to the camera. Walking to it and swinging the
// tool is done with synthetic touches in main.cpp; nothing here writes to the
// game. The glowing "X" bonus spot is looked up as a child GameObject of the
// node, so the swings land on it when the game shows one.

// Farm kind from a loot item short name. Rank: richer resource wins (metal and
// sulfur nodes drop stones too). Processed items are filtered like the ore
// markers, so barrels never register.
static int farm_kind_for_item_name(const char* item_name, int& kind) {
    if (!item_name || !item_name[0]) return 0;
    char key[40];
    size_t n = 0;
    for (const char* p = item_name; *p && n + 1 < sizeof(key); ++p) {
        char c = *p;
        if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
        key[n++] = c;
    }
    key[n] = '\0';
    if (strstr(key, "frag") || strstr(key, "pipe") || strstr(key, "sheet") ||
        strstr(key, "scrap") || strstr(key, "spring") || strstr(key, "gear"))
        return 0;
    if (strstr(key, "sulfur")) { kind = 3; return 4; }
    if (strstr(key, "metal"))  { kind = 2; return 3; }
    if (strstr(key, "stone"))  { kind = 1; return 2; }
    if (strstr(key, "wood"))   { kind = 0; return 1; }
    return 0;
}

// Same two loot lists the markers read, but wood ranks too (trees are the
// whole point here, while the markers skip them to keep the screen clean).
static bool farm_kind_from_loot(uint64_t mineable, int& kind) {
    const uint64_t sources[2] = {MINEABLE_LOOT, MINEABLE_FINISH_BONUS};
    int best = 0;
    for (uint64_t source : sources) {
        uint64_t items[12];
        int count = read_managed_collection(rd_ptr(mineable + source), items, 12);
        for (int i = 0; i < count; ++i) {
            if (!valid_obj(items[i])) continue;
            char name[32] = {};
            if (!read_managed_string(rd_ptr(items[i] + LOOTITEM_ITEM_NAME), name, sizeof(name))) continue;
            int candidate = 0;
            int rank = farm_kind_for_item_name(name, candidate);
            if (rank > best) { best = rank; kind = candidate; }
            if (best == 4) return true;
        }
    }
    return best > 0;
}

// ---- Скан реестра: порциями и с отрицательным кешем -------------------------
// Жалоба пользователя: «при включении автофарма минуту лагают все визуалы, потом
// иногда подлагивает». Замер по логу 14.09: кадр оверлея в норме 8.5 мс, но 153
// кадра из 10053 вырастали до 12..34 мс, и интервалы между ними складываются в
// периодический рисунок 8/52/68/112 кадров — это ресканы. Один проход стоил
// столько, сколько записей в NetworkClient.spawned: у каждой читались класс,
// список компонентов и сами компоненты (~10 чтений), а объектов в мире
// тысячи. Десятки тысяч чтений одним кадром — тот самый рывок, который видно
// глазом; на 118 fps скан к тому же запускался вдвое чаще задуманного, потому
// что счётчик был в кадрах из расчёта на 60 fps.
//
// Теперь три вещи сразу:
//   1) отрицательный кеш: запись, у которой в компонентах нет MineableObject,
//      запоминается вместе с указателем её списка компонентов и в следующих
//      проходах проверяется ОДНИМ чтением вместо десяти: пока поле указывает на
//      тот же список, объект тот же и вердикт в силе. Адрес освободившегося
//      объекта игра может отдать новому (в том числе узлу добычи) — тогда поле
//      почти наверняка смотрит на другой список, запись выбрасывается и объект
//      классифицируется заново. Узлов добычи в мире десятки, прочих объектов
//      тысячи, поэтому установившийся проход стоит по одному чтению на запись;
//   2) порционность: расход кадра задан в условных чтениях (kFarmScanBudget),
//      сверка с кешем стоит одно чтение, классификация новой записи — около
//      двенадцати, поэтому даже холодный проход растягивается по кадрам и ни
//      один кадр не платит за весь мир сразу;
//   3) результат прохода подменяет рабочий список ЦЕЛИКОМ в конце: пока проход
//      идёт, бот работает по прежнему списку. Прежняя гарантия («сбой чтения не
//      должен вычищать кеш — иначе маркер пропадал и бот вставал») сохранена и
//      усилена: окна «целей нет» на время скана больше не существует вовсе.
// identity -> указатель её списка компонентов на момент вердикта «не узел».
static std::unordered_map<uint64_t, uint64_t> g_farm_not_node;
static std::vector<uint64_t>   g_farm_scan_ids;       // записи текущего прохода
static size_t                  g_farm_scan_idx = 0;   // курсор прохода
static std::vector<FarmEntity> g_farm_scan_stage;     // накопленный результат
static bool                    g_farm_scan_run = false;
// Сколько условных единиц бюджета скан потратил на прошлом кадре и сколько
// записей реестра в нём всего/осталось. Печатается в строке «кадры оверлея»:
// по этим числам видно, идёт ли проход прямо сейчас и насколько он длинный.
static int                     g_farm_scan_units = 0;
static int                     g_farm_scan_total = 0;
static int                     g_farm_scan_new   = 0;

// Бюджет прохода — в условных чтениях за кадр, а не в записях: сверка с кешем
// стоит одно чтение, классификация новой записи — около двенадцати (класс,
// список, компоненты, трансформ, иногда имя префаба и loot-списки). Пока целей
// нет вовсе (старт фарма, перезагрузка мира), бот просто стоит, поэтому идём
// вчетверо быстрее; когда список есть — спешить некуда, старый список остаётся
// рабочим до конца прохода.
constexpr int    kFarmScanBudget     = 200;  // мягкий бюджет, единицы чтения/кадр
constexpr int    kFarmScanBudgetFast = 600;  // пока рабочий список пуст
constexpr int    kFarmScanCostCached = 1;    // сверка записи из кеша
constexpr int    kFarmScanCostNew    = 12;   // классификация новой записи
constexpr double kFarmScanPeriod   = 2.0;   // с между проходами, когда узлы есть
constexpr double kFarmScanRetry    = 0.5;   // с, когда список пуст (мир грузится)
constexpr size_t kFarmNegCacheMax  = 16384; // потолок кеша, записей

// Бросить незавершённый проход (смена маски ресурсов, перезагрузка мира).
void farm_scan_abort() {
    g_farm_scan_run = false;
    g_farm_scan_idx = 0;
    g_farm_scan_ids.clear();
    g_farm_scan_stage.clear();
}

// Полный сброс скана: рабочий список чистит вызывающий, здесь — кеш и проход.
void farm_scan_reset() {
    farm_scan_abort();
    g_farm_not_node.clear();
    g_farm_next_scan = 0.0;
}

// Вердикт по одной записи реестра:
//   0 — структурно не узел добычи; behaviours — её список компонентов (по нему
//       запись потом сверяется одним чтением вместо полной классификации);
//   1 — узел есть, но сейчас он не наш: маска ресурсов, сбой чтения, ещё не
//       изучена раскладка трансформов. Запоминать НЕЛЬЗЯ — условие временное;
//   2 — наш узел, entity заполнена (transform, required_purpose, pos);
//   3 — запись вообще не NetworkIdentity: кешировать нечего, повторная проверка
//       и так стоит одно чтение за проход.
static int farm_classify_identity(uint64_t identity, uint64_t identity_class,
                                  FarmEntity& entity, uint64_t& behaviours) {
    behaviours = 0;
    if (identity_class && rd_ptr(identity) != identity_class) return 3;
    uint64_t array = rd_ptr(identity + NETID_BEHAVIOURS);
    if (!valid_obj(array)) return 3;
    behaviours = array;
    int32_t behaviour_count = rd<int32_t>(array + IL2CPP_ARRAY_LENGTH);
    if (behaviour_count <= 0) return 0;
    if (behaviour_count > 32) behaviour_count = 32;
    uint64_t comps[32];   // список компонентов (behaviours — выходной параметр)
    if (!rd_buf(array + IL2CPP_ARRAY_FIRST_ELEMENT, comps,
                (size_t)behaviour_count * sizeof(uint64_t)))
        return 1;   // словарь переписывают на ходу: не вердикт, а повод повторить

    // Kind: the entityType enum first (cheap and exact), loot second.
    uint64_t component = 0;
    int kind = -1;
    for (int32_t b = 0; b < behaviour_count && kind < 0; ++b) {
        const uint64_t cand = comps[b];
        if (!valid_obj(cand)) continue;
        if (marker_class_of(rd_ptr(cand)) != MARKER_CLASS_MINEABLE) continue;
        component = cand;
        switch ((MineableEntityType)rd<int32_t>(component + MINEABLE_ENTITY_TYPE)) {
            case MineableEntityType::Tree:   kind = 0; break;
            case MineableEntityType::Stone:  kind = 1; break;
            case MineableEntityType::Iron:   kind = 2; break;
            case MineableEntityType::Sulfur: kind = 3; break;
            default: break;
        }
        if (kind < 0 && !farm_kind_from_loot(component, kind)) kind = -1;
    }
    if (!component) return 0;   // в компонентах нет MineableObject — не узел
    if (kind < 0) return 1;     // узел, но ресурс не опознан (сбой чтения)
    if (!(g_farm_mask & (1u << kind))) return 1;   // маску меняют на лету

    entity.identity = identity;
    entity.component = component;
    entity.kind = kind;
    entity.transform = native_component_transform(managed_object_native(component));
    if (!entity.transform)
        entity.transform = native_component_transform(managed_object_native(identity));
    if (!entity.transform) return 1;   // раскладка трансформов ещё не изучена

    // Fallen logs register as "Tree" but cannot be chopped the same way — the
    // bot just circles them. Filter them out by prefab name (log / fallen /
    // dead / driftwood variants). Вердикт структурный, поэтому бревно уходит в
    // отрицательный кеш: чтение имени (несколько syscall'ов плюс строка) больше
    // не повторяется на каждом проходе.
    if (kind == 0 && g_go_name_offset_valid) {
        char go_name[48];
        if (read_transform_name(entity.transform, go_name, sizeof(go_name))) {
            for (char* p = go_name; *p; ++p)
                if (*p >= 'A' && *p <= 'Z') *p = (char)(*p - 'A' + 'a');
            if (strstr(go_name, "log") || strstr(go_name, "fallen") ||
                strstr(go_name, "dead") || strstr(go_name, "driftwood") ||
                strstr(go_name, "stump"))
                return 0;
        }
    }

    // Чем этот узел вообще можно взять. Мусорное значение (не из набора флагов)
    // считаем отсутствием требования, чтобы ошибка чтения не оставила фарм без
    // целей.
    {
        const int32_t known = (int32_t)ToolPurpose::CutWood |
                              (int32_t)ToolPurpose::BreakRocks |
                              (int32_t)ToolPurpose::CutAnimals;
        const int32_t purpose = rd<int32_t>(component + MINEABLE_REQUIRED_TOOL_PURPOSE);
        entity.required_purpose = ((purpose & ~known) == 0) ? (int)purpose : 0;
    }

    entity.pos_valid = marker_world_position(entity.transform, entity.pos);
    return 2;
}

// Один шаг скана. Вызывается каждый кадр; сам решает, пора ли начинать проход и
// не пора ли его закончить. Дороже kFarmScanBudget записей за кадр не делает.
static void farm_scan_tick() {
    const double now = mono_seconds();
    if (!g_farm_scan_run && now < g_farm_next_scan) return;

    if (!g_farm_scan_run) {
        // Начало прохода. Сам словарь читается одним куском (это дёшево), а вот
        // классификация записей растягивается по кадрам. Сбой чтения здесь не
        // вердикт: рабочий список не тронут, повторим через kFarmScanRetry.
        uint64_t dictionary = resolve_network_client_spawned();
        if (!dictionary) { g_farm_next_scan = now + kFarmScanRetry; return; }
        uint64_t entries = rd_ptr(dictionary + DICT_ENTRIES);
        int32_t count = rd<int32_t>(dictionary + DICT_COUNT);
        if (!valid_obj(entries) || count <= 0) {
            g_farm_next_scan = now + kFarmScanRetry;
            return;
        }
        if (count > 4096) count = 4096;
        std::vector<uint8_t> buffer((size_t)count * DICT_ENTRY_STRIDE);
        if (!rd_buf(entries + IL2CPP_ARRAY_FIRST_ELEMENT, buffer.data(), buffer.size())) {
            g_farm_next_scan = now + kFarmScanRetry;
            return;
        }
        g_farm_scan_ids.resize((size_t)count);
        g_farm_scan_total = count;
        for (int32_t i = 0; i < count; ++i)
            memcpy(&g_farm_scan_ids[(size_t)i],
                   buffer.data() + (size_t)i * DICT_ENTRY_STRIDE + DICT_ENTRY_VALUE,
                   sizeof(uint64_t));
        g_farm_scan_idx = 0;
        g_farm_scan_stage.clear();
        g_farm_scan_run = true;
        // Фильтр поваленных брёвен нуждается в смещении имени GameObject.
        // Ищем его раз на проход (а не каждый кадр прохода): попытка стоит
        // обхода поддерева трансформов, см. ensure_gameobject_name_offset.
        if (!g_go_name_offset_valid && g_local_player)
            ensure_gameobject_name_offset(g_local_player);
    }

    const uint64_t identity_class = resolve_network_identity_class();

    int budget = g_farm_entities.empty() ? kFarmScanBudgetFast : kFarmScanBudget;
    g_farm_scan_units = 0;
    g_farm_scan_new = 0;
    while (g_farm_scan_idx < g_farm_scan_ids.size()) {
        const uint64_t identity = g_farm_scan_ids[g_farm_scan_idx++];
        if (!valid_obj(identity)) continue;
        const auto cached = g_farm_not_node.find(identity);
        const int cost = (cached != g_farm_not_node.end()) ? kFarmScanCostCached
                                                           : kFarmScanCostNew;
        if (budget < cost) { --g_farm_scan_idx; break; }  // доработаем в следующем кадре
        budget -= cost;
        g_farm_scan_units += cost;
        if (cost == kFarmScanCostNew) ++g_farm_scan_new;

        if (cached != g_farm_not_node.end()) {
            // Одно чтение: список компонентов на месте и тот же — объект не
            // сменился, вердикт «не узел добычи» остаётся в силе.
            if (rd_ptr(identity + NETID_BEHAVIOURS) == cached->second) continue;
            g_farm_not_node.erase(cached);   // адрес переиспользовали
        }

        FarmEntity entity;
        uint64_t behaviours = 0;
        const int verdict = farm_classify_identity(identity, identity_class, entity, behaviours);
        if (verdict == 0) {
            if (behaviours && g_farm_not_node.size() < kFarmNegCacheMax)
                g_farm_not_node.emplace(identity, behaviours);
            continue;
        }
        if (verdict != 2) continue;
        g_farm_scan_stage.push_back(entity);
        if (g_farm_scan_stage.size() >= 512) {
            g_farm_scan_idx = g_farm_scan_ids.size();
            break;
        }
    }
    if (g_farm_scan_idx < g_farm_scan_ids.size()) return;   // проход не закончен

    g_farm_entities = std::move(g_farm_scan_stage);
    g_farm_scan_stage.clear();
    g_farm_scan_ids.clear();
    g_farm_scan_idx = 0;
    g_farm_scan_run = false;
    // Пустой результат означает «реестр ещё не читается / мир грузится после
    // респауна» — повторяем чаще, но всё равно не каждый кадр.
    g_farm_next_scan = now + (g_farm_entities.empty() ? kFarmScanRetry : kFarmScanPeriod);
}

void esp_farm_set_resources(unsigned mask) {
    if (g_farm_mask != mask) {
        g_farm_mask = mask;
        g_farm_entities.clear();
        // Проход скана, если он шёл, собран под старой маской — выбрасываем его
        // и начинаем заново. Отрицательный кеш при этом жив: «нет компонента
        // MineableObject» от выбранных галочек ресурсов не зависит.
        farm_scan_abort();
        g_farm_next_scan = 0.0;
    }
    if (!mask) g_farm_blacklist.clear();
}

// Search radius for farm nodes, metres. Set from the menu slider.
static float g_farm_max_distance = 100.0F;

void esp_farm_set_range(float meters) {
    if (!std::isfinite(meters)) return;
    if (meters < 10.0F) meters = 10.0F;
    if (meters > 300.0F) meters = 300.0F;
    g_farm_max_distance = meters;
}

void esp_farm_blacklist(unsigned long long id, float seconds) {
    if (!id) return;
    int frames = (int)(seconds * 60.0F);
    if (frames < 60) frames = 60;
    g_farm_blacklist[(uint64_t)id] = frames;
    // Drop it from the cache right away and rescan soon: keeping a dead
    // node around until the next 2 s rescan is what made the bot jerk the
    // camera at garbage coordinates after finishing a tree.
    for (auto it = g_farm_entities.begin(); it != g_farm_entities.end(); ++it) {
        if (it->identity == (uint64_t)id) { g_farm_entities.erase(it); break; }
    }
    const double soon = mono_seconds() + 0.25;
    if (g_farm_next_scan > soon) g_farm_next_scan = soon;
}

// ---- Крестик: читаем из памяти, а не угадываем ------------------------------
// Старая реализация искала X перебором детей узла (по именам, LOD-мешам и
// «прыгающему» трансформу) и потому регулярно целилась в ствол, в спящий
// шаблон на пивоте или в корень под землёй — отсюда половина багов автофарма.
//
// Игра хранит крестик сама, и хранит его там, где его же и проверяет:
//   MineableObject.QWD (0xE8) — массив JE-экстеншенов узла, заполняется в
//   MineableObject.cik() (GetComponents<JE> на GameObject узла), который
//   вызывается из OnStartClient -> ciQ() и при каждом попадании (SRl -> cik).
//     руда   -> MineableObjectExtension_OreHitstreaks, живой клон в MoW (0x30);
//               мировая позиция его transform'а и есть точка крестика —
//               именно её читает проверка попадания OreHitstreaks.os().
//     дерево -> MineableObjectExtension_TreeHitstreaks, живой клон в MTn (0x50),
//               а точка попадания на коре — Vector3 в MTQ (0x88); проверка
//               попадания (giL и обвязка rRS/DMU/Dne/DfW) меряет дистанцию от
//               точки удара до отрезка MTQ..MTu с радиусом 0.15 м.
//
// X существует не всегда: игра создаёт его при ПЕРВОМ попадании по узлу
// (JE.gir) и уничтожает через 15 секунд простоя (OreHitstreaks.giq /
// TreeHitstreaks.gie обнуляют MoW/MTn и вызывают Object.Destroy на маркере).
// Поэтому «крестика нет» — штатное состояние: бьём по корпусу, первый удар
// создаёт X, и дальше все удары идут уже в него.
static constexpr const char* kFarmExtOreClass  = "MineableObjectExtension_OreHitstreaks";
static constexpr const char* kFarmExtTreeClass = "MineableObjectExtension_TreeHitstreaks";

enum { FARM_EXT_NONE = 0, FARM_EXT_ORE = 1, FARM_EXT_TREE = 2 };

// Крестик обязан лежать на узле: у руды его ставит Collider.ClosestPoint
// (поверхность камня), у дерева — рейкаст по стволу. Всё, что
// дальше нескольких метров от пивота, — мусор чтения или маркер соседнего узла.
static bool farm_spot_on_node(const Vec3& spot, const Vec3& node, int kind) {
    const float dx = spot.x - node.x, dy = spot.y - node.y, dz = spot.z - node.z;
    if (!std::isfinite(dx) || !std::isfinite(dy) || !std::isfinite(dz)) return false;
    const float max_h  = (kind == 0) ? 6.0F : 4.0F;   // крона/ствол vs камень
    const float max_up = (kind == 0) ? 26.0F : 9.0F;
    return (dx * dx + dz * dz) <= max_h * max_h && dy >= -8.0F && dy <= max_up;
}

// JE-экстеншен крестика для узла. QWD заполняется игрой при OnStartClient,
// поэтому обычно находится с первого раза; если кеш ещё пуст — повторяем раз в
// полсекунды (чтение имён классов дорогое, гонять его каждый кадр нельзя).
static void farm_resolve_extension(FarmEntity& entity) {
    if (entity.ext_kind != FARM_EXT_NONE && valid_obj(entity.ext)) return;
    if (entity.ext_age > 0) { --entity.ext_age; return; }
    entity.ext_age = 30;                       // ~0.5 с до следующей попытки
    entity.ext = 0;
    entity.ext_kind = FARM_EXT_NONE;
    if (!valid_obj(entity.component)) return;

    uint64_t items[8];
    const int count = read_managed_collection(rd_ptr(entity.component + MINEABLE_EXTENSIONS),
                                              items, 8);
    for (int i = 0; i < count; ++i) {
        const uint64_t obj = items[i];
        if (!valid_obj(obj)) continue;
        if (object_class_name_is(obj, kFarmExtOreClass)) {
            entity.ext = obj; entity.ext_kind = FARM_EXT_ORE; return;
        }
        if (object_class_name_is(obj, kFarmExtTreeClass)) {
            entity.ext = obj; entity.ext_kind = FARM_EXT_TREE; return;
        }
    }
}

// Мировая точка крестика и откуда она взялась (для диагностики в меню).
// source: 1 — трансформ маркера руды, 2 — точка на коре дерева (MTQ, либо
// ближайшая к глазу точка отрезка MTQ..MTu — именно до отрезка игра меряет
// попадание), 3 — трансформ декаля дерева (запасной путь; декаль смещён от
// коры на 0.25 м по нормали, поэтому он второй).
// life_left — сколько секунд крестику осталось жить (0 = уже потух, -1 = не
// прочиталось).
// Сколько секунд жизни осталось у крестика: у руды возраст (lHG) сравнивается
// с 15.0 прямо в OreHitstreaksMarker.Update, у дерева — свой lifetime, который
// HitMarkerItem.Update набирает в lzr. Мусорное значение отдаёт -1 («не
// знаю»), и тогда вызывающий код ведёт себя как раньше.
// Возвращает остаток жизни в секундах; 0.0F — ровно «потух» (вызывающий код
// сравнивает с нулём), -1.0F — «не прочиталось» (тогда верим полю маркера, как
// раньше, чтобы сбой чтения не лишал бота крестика).
static float farm_marker_life_left(uint64_t marker, uint64_t age_offset, float lifetime) {
    float age = 0.0F;
    if (!rd_exact(marker + age_offset, age) || !std::isfinite(age) || age < 0.0F) return -1.0F;
    if (!(lifetime > 0.0F)) return -1.0F;
    const float left = lifetime - age;
    return left > 0.0F ? left : 0.0F;
}

// Диагностика крестика для лога автофарма: что реально лежит в полях сегмента
// дерева (SPOT_A = точка на коре, SPOT_B = конец сегмента) и почему точка на
// коре не стала точкой прицела. В логе 14.09.2026 источник был 3 (декаль) во
// всех 10887 строках и ни разу 2 (кора) — без сырых значений не отличить «поля
// пусты» от «значения есть, но проверка их отвергла».
// Сглаженный радиус ствола на высоте крестика (см. постановку прицела на кору
// в esp_farm_get_target). Один узел за раз, поэтому хватает одной ячейки.
static unsigned long long s_bark_id = 0;
static float              s_bark_r  = -1.0F;

static Vec3  g_farmSpotRawA{}, g_farmSpotRawB{};
static int   g_farmSpotRawWhy = 3;      // 0 A принят, 1 не конечен, 2 вне узла, 3 не читали
static float g_farmSpotRawLen = -1.0F;  // |A-B| в метрах, -1 = не считалось

void esp_farm_spot_raw(float& ax, float& ay, float& az, float& bx, float& by, float& bz,
                       int& why, float& len) {
    ax = g_farmSpotRawA.x; ay = g_farmSpotRawA.y; az = g_farmSpotRawA.z;
    bx = g_farmSpotRawB.x; by = g_farmSpotRawB.y; bz = g_farmSpotRawB.z;
    why = g_farmSpotRawWhy; len = g_farmSpotRawLen;
}

static bool farm_read_spot(const FarmEntity& entity, Vec3& out, int& source, int& streak, float& life_left) {
    out = {}; source = 0; streak = 0; life_left = -1.0F;
    g_farmSpotRawA = {}; g_farmSpotRawB = {}; g_farmSpotRawWhy = 3; g_farmSpotRawLen = -1.0F;
    if (!valid_obj(entity.ext)) return false;

    if (entity.ext_kind == FARM_EXT_ORE) {
        // MoW == null означает «крестика сейчас нет» — игра сама обнуляет поле,
        // когда X потух (giq: Destroy маркера + str xzr,[x19,#0x30]).
        const uint64_t marker = rd_ptr(entity.ext + OREHS_MARKER);
        if (!valid_obj(marker)) return false;
        // Обнуление поля и гашение GameObject происходят не одним тактом, а
        // отсчёт своих 15 секунд маркер ведёт сам (Update: lHG += dt; lHG > 15
        // -> SetActive(false) + вызов владельца). Пока поле ещё заполнено, но
        // время вышло, прицел стоит на невидимой точке и удары уходят в никуда.
        const float life = farm_marker_life_left(marker, OREMARK_AGE, OREMARK_LIFETIME);
        if (life == 0.0F) return false;
        const uint64_t transform = native_component_transform(managed_object_native(marker));
        if (!transform || !marker_world_position(transform, out)) return false;
        if (!farm_spot_on_node(out, entity.pos, entity.kind)) return false;
        const int32_t s = rd<int32_t>(entity.ext + OREHS_STREAK_INDEX);
        streak = (s >= 0 && s < 10000) ? s : 0;
        life_left = life;
        source = 1;
        return true;
    }

    if (entity.ext_kind == FARM_EXT_TREE) {
        // Все проверки попадания у дерева начинаются с MTn != null — без живого
        // клона серия не засчитывается, так что это и есть признак «X есть».
        const uint64_t marker = rd_ptr(entity.ext + TREEHS_MARKER);
        if (!valid_obj(marker)) return false;
        // HitMarkerItem живёт свой lifetime, а по истечении уходит в пул
        // (Update: lzr += dt; lzr > lifetime -> вызов владельца lzT), где его
        // переиспользуют для другого дерева. Возраст поэтому проверяем до того,
        // как поверить в координаты.
        float lifetime = 0.0F;
        if (!rd_exact(marker + HITMARK_LIFETIME, lifetime) || !std::isfinite(lifetime) || lifetime < 0.0F)
            lifetime = 0.0F;
        const float life = farm_marker_life_left(marker, HITMARK_AGE, lifetime);
        if (life == 0.0F) return false;
        const int32_t s = rd<int32_t>(entity.ext + TREEHS_STREAK);
        streak = (s >= 0 && s < 10000) ? s : 0;

        // MTQ/MTu (0x88/0xA4) — ЛОКАЛЬНЫЕ координаты дерева, а не мировые:
        // в логе 14.09 у всех 6 крестиков A = (0, h, 0) — точка на ОСИ ствола
        // на высоте X, — а B отстоит от неё на радиус ствола (0.40 м у дерева
        // с корой 0.354 м, 0.04 м у тонкого, у которого кора 0.037 м). Отношение
        // к мировым размерам одинаковое для обоих (0.885 и 0.93) — это масштаб
        // дерева. Мировой точкой A поэтому быть не может (узел в 1200 м от
        // начала координат), и прежняя ветка «прицел = A» была мертва: она
        // срабатывала только у деревьев рядом с (0,0,0) и давала там мусор.
        // Сами значения нужны — из них берётся радиус ствола на высоте X
        // (см. постановку прицела на кору в esp_farm_get_target).
        const Vec3 a = rd_v3(entity.ext + TREEHS_SPOT_A);
        const Vec3 b = rd_v3(entity.ext + TREEHS_SPOT_B);
        g_farmSpotRawA = a;
        g_farmSpotRawB = b;
        if (vec3_is_finite(a) && vec3_is_finite(b)) {
            const float lx = b.x - a.x, ly = b.y - a.y, lz = b.z - a.z;
            g_farmSpotRawLen = sqrtf(lx * lx + ly * ly + lz * lz);
        }
        g_farmSpotRawWhy = !vec3_is_finite(a) ? 1
                         : !farm_spot_on_node(a, entity.pos, entity.kind) ? 2 : 0;
        // Мировая точка X берётся из трансформа декали (единственный источник
        // мировых координат крестика), а локальный отрезок A..B идёт на радиус
        // ствола: декаль стоит не на коре, поэтому прицел отдельно ставится на
        // кору — см. «Точка крестика на коре» в esp_farm_get_target.
        // Проверка попадания у дерева меряет дистанцию до ОТРЕЗКА MTQ..MTu
        // радиусом 0.15 м: прицел на коре в направлении декали попадает ровно
        // в конец B этого отрезка, то есть в середину допуска.
        const uint64_t mark = rd_ptr(marker + HITMARK_MARK);
        uint64_t transform = valid_obj(mark) ? managed_object_native(mark) : 0;
        if (!transform) transform = native_component_transform(managed_object_native(marker));
        if (!transform || !marker_world_position(transform, out)) return false;
        if (!farm_spot_on_node(out, entity.pos, entity.kind)) return false;
        life_left = life;
        source = 3;
        return true;
    }
    return false;
}

void esp_farm_debug(int& nodes_cached, int& idle_reason) {
    nodes_cached = (int)g_farm_entities.size();
    idle_reason = g_farm_idle_reason;
}

void esp_farm_tool_info(int& purposes_have, int& purposes_need) {
    purposes_have = g_farm_tool_have;
    purposes_need = g_farm_tool_need;
}

// Упёрся ли луч прицела в САМ узел добычи, а не в перекрытие.
//
// Зачем: у камня точка прицела — пивот узла с зажимом по высоте, то есть точка
// ВНУТРИ породы. Луч игры останавливается на ближней поверхности камня гораздо
// раньше неё (лог 14.09, узел 86a3c0: ray 0.51..0.77 м при aim_3d 1.97..2.33 м
// на всех 1595 кадрах окна), поэтому прежняя формула «луч дошёл заметно раньше
// точки прицела => перекрыт» принимала за стену собственный камень. Дальше
// контроллер честно отрабатывал перекрытие: «перекрыт — обхожу», круги вокруг
// узла, ноль тапов и ноль крестиков. Дерево при этом работало: там поправка на
// кору ставит прицел НА поверхность, ray_distance ≈ aim_3d и «перекрыт» не
// возникало — на деревья эта проверка не влияет.
//
// Удар по своему же камню игра засчитывает: FPMelee.ZkX сравнивает с
// m_MaxReach + hitRadius distance ЭТОГО луча (0.5..0.8 м при дальности 1.5 м),
// а не нашу дистанцию до точки прицела. После первого удара OreHitstreaks.giu
// ставит X через Collider.ClosestPoint — уже на поверхности, и дальше прицел
// стоит на крестике, как у дерева.
//
// Своим считается попадание по любому из двух признаков:
//   1) m_Collider луча — коллайдер экстеншена руды (OREHS_COLLIDER: тот самый
//      Collider, которым игра ставит X). Сначала сравниваем managed-указатели
//      напрямую, потом их нативные объекты — обёртка может быть другой;
//   2) GameObject попадания — GameObject узла. У узла в кеше transform уже
//      нативный, у попадания managed, поэтому сравниваем нативные.
// Вызывается только когда старая формула сказала «перекрыт», так что лишние
// чтения (3..5) достаются лишь редким кадрам с реальным подозрением на стену.
// Трансформ, о который остановился луч: у попадания есть GameObject (managed,
// читаем его native), а у коллайдера — прямой путь до Transform. Коллайдер
// точнее (это ровно та геометрия, в которую попал луч), GameObject — запасной
// путь, когда m_Collider пуст.
static uint64_t ray_hit_transform(const MeleeReach& reach) {
    if (reach.ray_collider) {
        const uint64_t col = managed_object_native(reach.ray_collider);
        if (col) {
            const uint64_t t = native_component_transform(col);
            if (t) return t;
        }
    }
    const uint64_t go = managed_object_native(reach.ray_hit_go);
    if (!go) return 0;
    const uint64_t pairs = rd_ptr(go + GAMEOBJECT_COMPONENT_ARRAY);
    if (!pairs) return 0;
    const uint64_t t = rd_ptr(pairs + COMPONENT_PAIR_PTR);
    if (!t || rd_ptr(t + COMPONENT_GAMEOBJECT) != go) return 0;
    return t;
}

// Лежит ли попадание луча ВНУТРИ поддерева узла.
//
// Проверка «GameObject попадания == GameObject узла» слишком строга: у камня и
// дерева меш с коллайдером висит на дочернем GameObject (LOD-модели, обломки,
// «корка»), и корневой GO узла с ним не совпадает НИКОГДА. Лог 15.09.2026 это и
// показал: у руды луч упирался в собственную породу (0.5 м при точке прицела
// 2.3 м), покидал узел как «перекрытый» — четыре обхода, чёрный список, ноль
// ударов. Поэтому сравниваем с ПОДДЕРЕВОМ трансформа узла: попадание в любую его
// деталь — это попадание в сам узел.
//
// Обход стоит несколько чтений на узел поддерева, поэтому вердикт кешируется по
// паре (узел, трансформ попадания): луч стоит в одной и той же детали десятки
// кадров подряд, а обход делается один раз.
static bool ray_hit_in_node_subtree(const MeleeReach& reach, const FarmEntity& node,
                                    uint64_t& hit_transform_out, int& nodes_walked) {
    hit_transform_out = 0;
    nodes_walked = 0;
    if (!node.transform) return false;
    const uint64_t hit_transform = ray_hit_transform(reach);
    if (!hit_transform) return false;
    hit_transform_out = hit_transform;
    if (hit_transform == node.transform) return true;

    static unsigned long long s_node_id = 0;
    static uint64_t s_hit_transform = 0;
    static bool     s_verdict = false;
    if (s_node_id == node.identity && s_hit_transform == hit_transform) return s_verdict;

    static std::vector<uint64_t> s_subtree;
    collect_transform_subtree(node.transform, s_subtree, 128);
    nodes_walked = (int)s_subtree.size();
    bool verdict = false;
    for (uint64_t t : s_subtree) {
        if (t == hit_transform) { verdict = true; break; }
    }
    s_node_id = node.identity;
    s_hit_transform = hit_transform;
    s_verdict = verdict;
    return verdict;
}

static bool ray_hit_is_self_node(const MeleeReach& reach, const FarmEntity& node, int& why) {
    why = 0;
    if (!reach.ray_valid || !reach.ray_hit_go) return false;
    // 1. Самая дешёвая проверка: коллайдер попадания — тот самый, которым игра
    //    ставит крестик руды (OREHS_COLLIDER, lzR). Поле заполняется в gir, то
    //    есть уже ПОСЛЕ первого попадания (и живёт, пока жив крестик).
    if (reach.ray_collider && node.ext && node.ext_kind == FARM_EXT_ORE) {
        // Сравнивать коллайдер крестика можно, только пока крестик ЖИВ: после
        // гашения поле может держать указатель на уничтоженный коллайдер, чей
        // адрес аллокатор уже отдал постройке — сравнение дало бы ложное
        // «попадание в свой узел» и удар по чужой стене.
        const uint64_t marker = rd_ptr(node.ext + OREHS_MARKER);
        if (valid_obj(marker)) {
            const uint64_t col = rd_ptr(node.ext + OREHS_COLLIDER);
            if (col && (col == reach.ray_collider ||
                        managed_object_native(col) == managed_object_native(reach.ray_collider))) {
                why = 1;
                return true;
            }
        }
    }
    if (!node.transform) return false;
    // 2. Коллайдер (или сам узел) висит на корневом GameObject узла.
    const uint64_t node_go = rd_ptr(node.transform + COMPONENT_GAMEOBJECT);
    if (!node_go) return false;
    if (managed_object_native(reach.ray_hit_go) == node_go) {
        why = 2;
        return true;
    }
    // 3. Меш с коллайдером — деталь узла: попадание внутрь его поддерева.
    uint64_t hit_transform = 0;
    int nodes_walked = 0;
    if (ray_hit_in_node_subtree(reach, node, hit_transform, nodes_walked)) {
        why = 3;
        return true;
    }
    return false;
}

static bool ray_hit_is_self_node(const MeleeReach& reach, const FarmEntity& node) {
    int why = 0;
    return ray_hit_is_self_node(reach, node, why);
}

// Сырая прикидка «где на узле сидит точка попадания» из самого узла, без
// крестика: MineableObject.LXX (0xC8) — Transform, который игра использует как
// якорь точки удара (ZgL() отдаёт его мировую позицию, а сам он живёт в
// hitInfo). Если это действительно якорь поверхности, он даёт точку прицела для
// руды ещё ДО первого удара — тогда «перекрытие собственным камнем» исчезает
// само, без всяких послаблений. Пока это только замер для лога: пишем позицию
// якоря и дистанцию до точки попадания луча, чтобы на устройстве увидеть,
// совпадают ли они (0.0x м = якорь на поверхности, десятки метров = мусор).
static bool farm_ore_anchor_point(const FarmEntity& node, Vec3& out, float& dist_to_ray, int& valid) {
    valid = 0;
    dist_to_ray = -1.0F;
    if (node.kind == 0 || !valid_obj(node.component)) return false;
    const uint64_t anchor = rd_ptr(node.component + MINEABLE_HIT_ANCHOR);
    if (!valid_obj(anchor)) return false;
    const uint64_t transform = native_component_transform(managed_object_native(anchor));
    if (!transform) return false;
    if (!marker_world_position(transform, out)) return false;
    valid = 1;
    return true;
}

// Санитары наведения по факту попадания: точка попадания и крестик обязаны
// стоять рядом, иначе это чужая геометрия или мусор чтения и править по ней
// курс нельзя. kAimDeltaMax — предел «сойдёт для правки» (узел большой, X может
// стоять на стволе/склоне заметно в стороне от текущего попадания),
// kAimDeltaNear — «попал вплотную к крестику, владелец уже не важен».
constexpr float kAimDeltaMax  = 1.20F;
constexpr float kAimDeltaNear = 0.60F;
// Предел поправки «по факту попадания»: она уточняет наведение по камере, но не
// имеет права рулить камерой сама — иначе необычная геометрия удара (луч в
// землю под крестиком, попадание в листву) мотала бы прицел из стороны в сторону.
constexpr float kAimFixMax = 2.00F;      // абсолютный предел трима, град
// Условия обучения трима: kAimFixSteadyDeg — насколько угол ПО КАМЕРЕ может
// дрогнуть между кадрами, чтобы считать камеру стоящей; kAimFixGeomM — насколько
// могут сдвинуться крестик и точка попадания (иначе геометрия удара ещё едет);
// kAimFixNearDeg — докуда до цели это имеет смысл.
constexpr float kAimFixSteadyDeg = 0.15F;
constexpr float kAimFixNearDeg   = 3.00F;
constexpr float kAimFixGeomM     = 0.05F;
// Насколько новый отсчёт может отличаться от текущего трима, чтобы ему верить;
// и с какой скоростью трим к нему ползёт (град за кадр ≈ 1.5°/с). Совпал ли
// отсчёт с тримом — это ещё и проверка «мы в покое, а не в переходном процессе».
constexpr float kAimFixLearnMax  = 0.80F;
constexpr float kAimFixRateDeg   = 0.025F;
// Если геометрия в покое и у цели, а отсчёт устойчиво расходится с тримом —
// поправка реально изменилась (сменилось оружие): тянем медленно.
constexpr float kAimFixPullDeg   = 0.010F;
constexpr int   kAimFixRejectFrames = 90;   // ~1.5 с

bool esp_farm_get_target(FarmTarget& out) {
    out = FarmTarget{};
    if (!g_farm_mask) { g_farm_idle_reason = 1; return false; }
    if (g_pid <= 0 || !g_il2cpp_base) { g_farm_idle_reason = 2; return false; }
    // Та же самопочинка, что у маркеров: если конвейер боксов не опубликовал
    // кадр (пустой список игроков и т.п.), собираем его прямо из камеры.
    if (!g_frame_local_valid || !g_frame_vp_valid) {
        if (!publish_camera_only_frame(g_last_overlay_sw, g_last_overlay_sh)) {
            g_farm_idle_reason = 2;
            return false;
        }
    }

    // Учёт чёрного списка (контроллер вызывает нас один раз в кадр).
    for (auto it = g_farm_blacklist.begin(); it != g_farm_blacklist.end();) {
        if (--(it->second) <= 0) it = g_farm_blacklist.erase(it);
        else ++it;
    }

    farm_scan_tick();

    // Липкая цель: пока текущий узел жив, работаем по нему — иначе контроллер
    // переключался бы между двумя равноудалёнными узлами каждый кадр.
    static uint64_t s_last_identity = 0;

    // Орудие в руках читаем один раз на кадр: из него и дальность удара, и ритм,
    // и умения (какой ресурс этим орудием вообще добывается).
    MeleeReach reach{};
    bool have_reach = false;
    have_reach = read_local_melee_reach(reach);
    g_farm_tool_have = (have_reach && reach.purposes_valid) ? reach.tool_purposes : 0;
    int tool_need = 0;

    const float kMaxFarmDistance = g_farm_max_distance;
    const FarmEntity* best = nullptr;
    float best_score = 1e18F;
    float best_dist = 0.0F;
    for (const FarmEntity& entity : g_farm_entities) {
        if (!(g_farm_mask & (1u << entity.kind))) continue;
        if (!entity.pos_valid) continue;
        if (g_farm_blacklist.count(entity.identity)) continue;

        // Узел, который нечем взять текущим орудием, целью не становится:
        // сравнение побитовое, тип у обоих полей один (FPTool.ToolPurpose).
        // Без этого бот с киркой в руках вечно кружил вокруг дерева (и
        // наоборот), теряя на каждый узел весь give-up таймер.
        if (have_reach && reach.purposes_valid && entity.required_purpose != 0 &&
            (reach.tool_purposes & entity.required_purpose) == 0) {
            tool_need |= entity.required_purpose;
            continue;
        }

        // Дистанция по горизонтали (в Unity ось Y вверх). Контроллер сравнивает
        // её с дальностью удара, а пивот высокого дерева сидит в метрах над
        // землёй — 3D-дистанция до него никогда не опускается до порога, из-за
        // чего бот вечно кружил вокруг тонких стволов.
        const float dx = entity.pos.x - g_frame_local_pos.x;
        const float dy = entity.pos.y - g_frame_local_pos.y;
        const float dz = entity.pos.z - g_frame_local_pos.z;
        const float dist = sqrtf(dx * dx + dz * dz);
        if (!std::isfinite(dist) || dist > kMaxFarmDistance) continue;
        // Узлы на другом вертикальном уровне (скала сверху/снизу) не берём.
        if (!std::isfinite(dy) || fabsf(dy) > 30.0F) continue;

        float score = dist;
        // Похоже добытые узлы отправляются в конец очереди, а не отсеиваются
        // сразу: точный смысл fractionRemaining на всех сборках не гарантирован,
        // и ошибочная догадка здесь оставила бы фарм вообще без целей. Если
        // оценка неверна, watchdog контроллера всё равно снимет узел за
        // секунды. Для ТЕКУЩЕЙ цели не делаем никогда: один мусорный замер
        // остатка в середине работы отправлял её в конец очереди, и метка
        // прыгала на другой узел, хотя этот был ещё наполовину полон.
        if (entity.identity != s_last_identity) {
            // Освежаем кешированный остаток не чаще раза в секунду на узел —
            // иначе один ближний узел стоил по syscall'у на узел каждый кадр.
            FarmEntity& mut = const_cast<FarmEntity&>(entity);
            if (--mut.frac_age <= 0) {
                // 120 кадров: «раз в секунду» задумывалось при 60 fps, а на
                // 118 fps выходило вдвое чаще — по syscall'у на каждый ближний
                // узел дважды в секунду.
                mut.frac_age = 120;
                mut.fraction = rd<float>(entity.component + MINEABLE_FRACTION);
            }
            if (std::isfinite(mut.fraction) && mut.fraction >= 0.0F &&
                mut.fraction <= 1.001F && mut.fraction < 0.03F)
                score += 1000.0F;
        } else {
            score *= 0.6F; // липкость
        }
        if (score < best_score) { best_score = score; best = &entity; best_dist = dist; }
    }
    if (!best) {
        s_last_identity = 0;
        g_farm_tool_need = tool_need;
        // 6 — рядом есть узлы, но текущим орудием они не добываются.
        g_farm_idle_reason = tool_need ? 6 : (g_farm_entities.empty() ? 3 : 4);
        return false;
    }
    g_farm_tool_need = 0;
    s_last_identity = best->identity;
    FarmEntity& node = const_cast<FarmEntity&>(*best);

    // ---- Жив ли ещё выбранный узел --------------------------------------------
    // Добытый узел игра уничтожает, а освободившуюся память аллокатор тут же
    // отдаёт под новые объекты — вплоть до коллайдера и GameObject ПОСТРОЙКИ.
    // Тогда проверки «луч упёрся в свой узел» (поддерево трансформов,
    // GameObject узла, коллайдер крестика) получают ложное подтверждение по
    // переиспользованным адресам, и бот со спокойной совестью бьёт по
    // постройке, в которую упёрся. Класс компонента у живого MineableObject
    // не меняется никогда: смена класса или невалидный объект = узел умер.
    // С дебаунсом (единичный сбой чтения не выкидывает живой узел) и БЕЗ
    // чёрного списка: ошиблись — следующий проход скана (2 с) вернёт узел.
    {
        static uint64_t s_alive_id = 0;
        static int      s_alive_bad = 0;
        if (best->identity != s_alive_id) { s_alive_id = best->identity; s_alive_bad = 0; }
        bool alive = false;
        if (valid_obj(node.component)) {
            const uint64_t klass = rd_ptr(node.component);
            alive = valid_obj(klass) && marker_class_of(klass) == MARKER_CLASS_MINEABLE;
        }
        if (alive) {
            s_alive_bad = 0;
        } else if (++s_alive_bad >= 10) {
            for (auto it = g_farm_entities.begin(); it != g_farm_entities.end(); ++it) {
                if (it->identity == best->identity) { g_farm_entities.erase(it); break; }
            }
            s_last_identity = 0;
            g_farm_idle_reason = 7;   // узел умер: память уже чужая
            return false;
        }
    }

    // ---- Крестик -------------------------------------------------------------
    Vec3 spot{};
    int spot_source = 0, streak = 0;
    float spot_life = -1.0F;
    bool has_spot = false;
    farm_resolve_extension(node);
    has_spot = farm_read_spot(node, spot, spot_source, streak, spot_life);

    // С какой стороны узла X. На удар сторона больше не влияет (удар идёт
    // наведением по X, и точка подхода теперь всегда ПЕРЕД крестиком — см.
    // ниже), поэтому флаг чисто диагностический: по нему видно, что бот
    // обходит узел кругом, чтобы встать к X лицом.
    bool spot_front = true;
    if (has_spot) {
        const float px = g_frame_local_pos.x - best->pos.x;
        const float pz = g_frame_local_pos.z - best->pos.z;
        const float sx = spot.x - best->pos.x;
        const float sz = spot.z - best->pos.z;
        const float pl = sqrtf(px * px + pz * pz);
        const float sl = sqrtf(sx * sx + sz * sz);
        // Только когда обе стороны различимы: у камня пивот бывает зарыт, и X
        // стоит почти над ним — там «сторона» не определена, считаем своей.
        if (pl > 0.35F && sl > 0.35F)
            spot_front = ((px * sx + pz * sz) / (pl * sl)) > -0.1F;
    }
    // Точка удара — крестик всегда, когда он есть, независимо от стороны.
    const bool at_spot = has_spot;

    // ---- Указатели маркеров (пин не используется, поля для диагностики) ------
    // esp_farm_cross_pin автофармом не включается (запись трансформа маркера
    // перестала проходить — удар идёт наведением), но указатели заполняем как
    // раньше: по ним видно, жив ли маркер, и они нужны, если пин вернём.
    // Дереву пин писал сегмент MTQ/MTu в экстеншене (локальные координаты узла
    // — потому и трансформ узла), руде — мировую позицию живого маркера
    // (именно её читает проверка серии OreHitstreaks.os()).
    out.cross_ext = valid_obj(node.ext) ? node.ext : 0;
    out.cross_node_transform = node.transform;
    if (node.ext_kind == FARM_EXT_ORE && valid_obj(node.ext)) {
        const uint64_t marker = rd_ptr(node.ext + OREHS_MARKER);
        if (valid_obj(marker)) {
            const uint64_t t = native_component_transform(managed_object_native(marker));
            if (t) out.cross_marker_transform = t;
        }
    } else if (node.ext_kind == FARM_EXT_TREE && valid_obj(node.ext)) {
        const uint64_t marker = rd_ptr(node.ext + TREEHS_MARKER);
        if (valid_obj(marker)) {
            const uint64_t mark = rd_ptr(marker + HITMARK_MARK);
            if (valid_obj(mark)) {
                const uint64_t t = managed_object_native(mark);   // mark — сам Transform
                if (t) out.cross_mark_transform = t;
            }
        }
    }

    // ---- Точка крестика: поставить на кору, а не на декаль и не внутрь ствола --
    // Декаль X висит СНАРУЖИ коры (сдвиг по нормали против z-файта), поэтому
    // прицел по ней на боку ствола уходил мимо дерева: луч «глаз -> декаль» не
    // цеплял меш, GKo оставался пустым и FPMelee.ZkX играл один On_Woosh.
    // Первая поправка тянула прицел к оси ствола на 0.25 м — «сдвиг декали из
    // дампа». Замер по логу 14.09 (55 замахов с живым лучом игры, у которого
    // известны и точка попадания m_Point, и нормаль) показал, что 0.25 м —
    // много: декаль торчит из коры в среднем на 0.108 м, а прицел после
    // поправки уходил на 0.138 м ВНУТРЬ ствола (min 0.178, max +0.063 снаружи).
    // Урон при этом шёл (луч цеплял кору), но попадание оказывалось в 15 см от
    // крестика — за пределами 0.15 м, которыми игра меряет серию по X, поэтому
    // серия не росла: «крестик сбоку, а бот по нему мажет».
    //
    // Правильная точка — пересечение направления на декаль с корой. Радиус
    // ствола на высоте X берём из того, что игра меряет сама, по убыванию
    // точности:
    //   1. точка попадания её же луча прицела (m_Point) — это буквально кора;
    //   2. локальный отрезок X (MTQ на оси ствола, MTu на коре): его длина —
    //      радиус в локальных единицах, а масштаб дерева получается из высоты
    //      декали над пивотом (декаль стоит на той же высоте, что и X). Замер:
    //      локальный радиус 0.40 при коре 0.354 и 0.04 при коре 0.037 —
    //      масштаб 0.885 и 0.93, оба сходятся с высотой (1.93 -> 1.74);
    //   3. ни луча, ни полей — декаль торчит примерно на 0.3 радиуса, то есть
    //      кора это 0.77 от её вылета (по замеру 0.757..0.788 на двух деревьях).
    // Направление всегда от декали: нормаль ствола почти радиальна, а величина
    // сдвига по нормали нам как раз неизвестна — она и есть ошибка.
    if (has_spot && node.kind == 0) {
        const float cdx = spot.x - node.pos.x, cdz = spot.z - node.pos.z;
        const float choriz = sqrtf(cdx * cdx + cdz * cdz);
        if (choriz > 0.05F) {
            float bark = -1.0F;
            // 1) кора из луча самой игры. Попадание обязано быть на ЭТОМ стволе:
            //    правдоподобный радиус, не дальше декали с запасом и рядом по
            //    высоте — иначе это земля, соседнее дерево или крона.
            if (reach.ray_point_valid && reach.ray_hit_object) {
                const float hx = reach.ray_point.x - node.pos.x;
                const float hz = reach.ray_point.z - node.pos.z;
                const float rh = sqrtf(hx * hx + hz * hz);
                if (std::isfinite(rh) && rh > 0.03F && rh < 2.5F &&
                    rh < choriz * 1.6F && fabsf(reach.ray_point.y - spot.y) < 1.2F)
                    bark = rh;
            }
            // 2) локальный отрезок X + масштаб дерева из высоты декали
            if (bark < 0.0F && node.ext && node.ext_kind == FARM_EXT_TREE) {
                const Vec3 la = rd_v3(node.ext + TREEHS_SPOT_A);
                const Vec3 lb = rd_v3(node.ext + TREEHS_SPOT_B);
                const float h_world = spot.y - node.pos.y;   // высота X над пивотом
                if (vec3_is_finite(la) && vec3_is_finite(lb) && la.y > 0.25F && h_world > 0.25F) {
                    const float scale = h_world / la.y;
                    if (scale > 0.15F && scale < 6.0F) {
                        const float dx = lb.x - la.x, dz = lb.z - la.z;
                        const float r_local = sqrtf(dx * dx + dz * dz);
                        if (r_local > 0.005F) bark = r_local * scale;
                    }
                }
            }
            // 3) совсем ничего не прочиталось
            if (bark < 0.0F) bark = choriz * 0.77F;

            if (std::isfinite(bark) && bark > 0.02F && bark < 2.5F) {
                // Радиус ствола величина почти постоянная, а измерение по лучу
                // шумит на сантиметры из кадра в кадр (луч попадает в разные
                // места коры). Сглаживаем и держим на узел: иначе прицел
                // ползает вместе с шумом, а точка подхода дёргается за ним.
                if (s_bark_id != node.identity) { s_bark_id = node.identity; s_bark_r = bark; }
                else s_bark_r += (bark - s_bark_r) * 0.25F;
                if (s_bark_r > 0.02F && s_bark_r < 2.5F && s_bark_r < choriz * 1.6F) {
                    const float k = s_bark_r / choriz;
                    spot.x = node.pos.x + cdx * k;
                    spot.z = node.pos.z + cdz * k;
                }
            }
        }
    }

    // ---- Стоит ли луч игры в самом узле --------------------------------------
    // Вердикт нужен дважды за кадр (наведение ниже и разрешение на замах в
    // конце), а обход поддерева узла стоит чтений, поэтому считаем один раз:
    // внутри ray_hit_is_self_node вердикт кеширован по паре (узел, трансформ
    // попадания), так что повторный вызов почти бесплатен.
    int ray_self_why = 0;
    const bool ray_on_node = reach.ray_hit_object && ray_hit_is_self_node(reach, node, ray_self_why);

    // ---- Точка удара (куда реально ложатся замахи) ---------------------------
    // Крестик есть — точка удара это ОН: камера ведёт крестик (см. look ниже),
    // и удар штатным лучом игры из центра экрана ложится ровно в него — так
    // растёт серия (дистанция точка удара -> маркер руды / отрезок MTQ..MTu
    // дерева, радиус 0.15 м). Крестика нет — корпус узла: первый удар создаст
    // X на той точке, куда он попал.
    Vec3 aim = has_spot ? spot : best->pos;
    if (!has_spot) aim.y += (best->kind == 0) ? 1.15F : 0.15F;

    // Полнокруговые углы от оси камеры (или выстрела): в отличие от
    // aim_angles_for() узел может быть и за спиной, поэтому проекция на
    // forward бывает отрицательной, а yaw охватывает +-180. Приоритет:
    // поза камеры > ось выстрела > базис из матрицы вида этого кадра
    // (последний есть на устройствах, где поза не читается — именно из-за него
    // фарм раньше висел в «нет позиции камеры»).
    const bool ok_ref   = g_aim_ref_valid  && farm_cam_source_ok(g_aim_ref_origin);
    const bool ok_pose  = g_cam_pose_valid && farm_cam_source_ok(g_cam_pos);
    const bool ok_frame = g_frame_cam_basis_valid && farm_cam_source_ok(g_frame_cam_pos);
    if (!ok_ref && !ok_pose && !ok_frame) {
        g_farm_idle_reason = 5;
        return false;
    }
    // Углы меряем от позы КАМЕРЫ, когда она читается: камеру мы и ведём, и
    // пишем мы её же накопитель — значит и ошибку наведения надо считать от
    // неё (покачивание look-root в ошибку попадать не должно). Ось выстрела и
    // базис кадра — запасные варианты для устройств без позы.
    const bool use_ref  = ok_ref && !ok_pose;
    const bool use_pose = !use_ref && ok_pose;
    const Vec3& origin = use_ref ? g_aim_ref_origin  : use_pose ? g_cam_pos     : g_frame_cam_pos;
    const Vec3& fwd    = use_ref ? g_aim_ref_forward : use_pose ? g_cam_forward : g_frame_cam_fwd;
    const Vec3& right  = use_ref ? g_aim_ref_right   : use_pose ? g_cam_right   : g_frame_cam_right;
    const Vec3& up     = use_ref ? g_aim_ref_up      : use_pose ? g_cam_up      : g_frame_cam_up;

    // ---- Куда ведём камеру ---------------------------------------------------
    // Камера ведёт ЦЕНТР КОРПУСА узла, когда крестика нет (первый удар по
    // корпусу его и создаёт) — точка стабильная, не прыгает. Как только X
    // появился, камера ведёт ЕГО: попадание в крестик обеспечивается наведением
    // штатного луча игры (крестик = центр экрана), а не пином маркера —
    // запись трансформов маркера на живой сборке перестала проходить, так что
    // в наведение крестик обязан попадать сам (см. farm.cpp, допуск наведения).
    // Исключение — луч уже ушёл в посторонний объект (ray_off_node): тогда
    // смотрим в корпус, чтобы вернуть луч на узел.
    Vec3 look = best->pos;
    look.y += (best->kind == 0) ? 1.15F : 0.15F;
    if (best->kind == 0) {
        const float lo = origin.y - 0.9F, hi = origin.y + 0.1F;
        if (look.y < lo) look.y = lo;
        if (look.y > hi) look.y = hi;
    } else {
        const float lo = origin.y - 1.3F, hi = origin.y - 0.55F;
        if (look.y < lo) look.y = lo;
        if (look.y > hi) look.y = hi;
    }
    // Крестик есть — ведём ЕГО, и всегда: раньше на кадр-другой луч мог уйти в
    // посторонний объект, и камера откатывалась в центр корпуса. Со стороны это
    // выглядело как «бот не доводится до крестика»: камера металась между X и
    // корпусом (это метры по высоте у дерева) и ни разу не вставала в X.
    // От «махать в чужое» это не спасает и не нужно: замах и так блокируется,
    // когда луч игры упёрся не в свой узел (swingByRay/ray_foreign в farm.cpp).
    const bool look_spot = has_spot;
    if (look_spot) look = spot;

    const Vec3 d = {look.x - origin.x, look.y - origin.y, look.z - origin.z};
    const float fx = d.x * fwd.x + d.y * fwd.y + d.z * fwd.z;
    const float rx = d.x * right.x + d.y * right.y + d.z * right.z;
    const float ux = d.x * up.x + d.y * up.y + d.z * up.z;
    if (!std::isfinite(fx) || !std::isfinite(rx) || !std::isfinite(ux)) {
        g_farm_idle_reason = 5;
        return false;
    }
    constexpr float rad2deg = 57.29577951F;
    const float yaw_cam   = atan2f(rx, fx) * rad2deg;
    const float pitch_cam = atan2f(ux, sqrtf(fx * fx + rx * rx)) * rad2deg;
    if (!std::isfinite(yaw_cam) || !std::isfinite(pitch_cam)) { g_farm_idle_reason = 5; return false; }

    // ---- Трим наведения «по факту попадания» ---------------------------------
    // Живой луч прицела игры (GKo.RaycastHit.m_Point) — буквально та точка, куда
    // уйдёт следующий замах. Мало выровнять камеру по крестику: между осью камеры
    // и осью удара стоят покачивание оружия, отдача и смещение точки старта луча.
    // Поэтому сравниваем две угловые меры ОДНОГО крестика:
    //   • по камере    — только что посчитанные yaw_cam/pitch_cam (угол между осью
    //     камеры и направлением на X из нашей точки старта);
    //   • по попаданию — угол между направлением луча (это та же ось камеры, но
    //     взятая из данных удара) и направлением на X из точки попадания:
    //     вектор (X - P) в осях камеры, угол = atan2(боковая, продольная), где
    //     продольная = dot(X - P, fwd) + ray_distance — расстояние до X вдоль оси
    //     (именно оно, а НЕ ray_distance: луч часто бьёт в близкую поверхность).
    // Разница мер — постоянный трим, который надо держать в наведении.
    //
    // Трим — свойство ОРУЖИЯ и камеры, а не крестика: он НЕ сбрасывается ни при
    // смене крестика (а игра переставляет X после каждого удара), ни при смене
    // узла. Учится он только «в покое» — когда стоит и поза камеры, и сама
    // геометрия удара (крестик и точка попадания не сдвинулись), — и ползёт к
    // отсчёту со скоростью kAimFixRateDeg за кадр. Пока камера едет или крестик
    // только что переехал, трим просто держит выученное значение: остальная
    // система в это время доводит камеру, и подмешивать в неё дрожащий отсчёт
    // (а тем более «доучивать» его) значит раскачивать прицел.
    static unsigned long long s_fix_id = 0;
    static float s_fix_y = 0.f, s_fix_p = 0.f;          // выученный трим
    static Vec3  s_fix_spot{}, s_fix_ray{};
    static bool  s_fix_have_prev = false;
    static int   s_fix_reject = 0;
    static float s_fix_prevY = 0.f, s_fix_prevP = 0.f;
    static bool  s_fix_prev_ok = false;
    if (s_fix_id != best->identity) {
        s_fix_id = best->identity; s_fix_prev_ok = false; s_fix_have_prev = false;
        s_fix_reject = 0;
    }

    const float fix_pose_steady = s_fix_prev_ok &&
        fabsf(yaw_cam - s_fix_prevY) < kAimFixSteadyDeg &&
        fabsf(pitch_cam - s_fix_prevP) < kAimFixSteadyDeg;
    s_fix_prevY = yaw_cam; s_fix_prevP = pitch_cam; s_fix_prev_ok = true;
    const bool fix_near = fabsf(yaw_cam) < kAimFixNearDeg &&
                          fabsf(pitch_cam) < kAimFixNearDeg;

    bool fix_sample_ok = false, fix_geom_steady = false;
    float fix_sample_y = 0.f, fix_sample_p = 0.f;
    if (has_spot && reach.ray_valid && reach.ray_point_valid) {
        const Vec3 e = {spot.x - reach.ray_point.x, spot.y - reach.ray_point.y,
                        spot.z - reach.ray_point.z};
        const float ex = e.x * right.x + e.y * right.y + e.z * right.z;
        const float eu = e.x * up.x    + e.y * up.y    + e.z * up.z;
        const float ef = e.x * fwd.x   + e.y * fwd.y   + e.z * fwd.z;
        const float elen = sqrtf(ex * ex + eu * eu + ef * ef);
        const float along = ef + reach.ray_distance;   // расстояние до X по оси
        // Годится и попадание в САМ узел, и попадание вплотную к крестику
        // (например, луч ушёл в землю под X). Дальнее чужое попадание
        // отбрасываем — по стене/соседнему узлу курс править нельзя.
        fix_sample_ok = std::isfinite(along) && along > 0.15F &&
                        std::isfinite(elen) && elen < kAimDeltaMax &&
                        (ray_on_node || elen < kAimDeltaNear);
        if (fix_sample_ok) {
            auto vdist = [](const Vec3& a, const Vec3& b) {
                const float dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
                return sqrtf(dx * dx + dy * dy + dz * dz);
            };
            fix_geom_steady = s_fix_have_prev &&
                              vdist(spot, s_fix_spot) < kAimFixGeomM &&
                              vdist(reach.ray_point, s_fix_ray) < kAimFixGeomM;
            s_fix_spot = spot; s_fix_ray = reach.ray_point; s_fix_have_prev = true;
            fix_sample_y = atan2f(ex, along) * 57.29577951F - yaw_cam;
            fix_sample_p = atan2f(eu, along) * 57.29577951F - pitch_cam;
            fix_sample_ok = std::isfinite(fix_sample_y) && std::isfinite(fix_sample_p);
            fix_sample_y = fminf(fmaxf(fix_sample_y, -kAimFixMax), kAimFixMax);
            fix_sample_p = fminf(fmaxf(fix_sample_p, -kAimFixMax), kAimFixMax);
        }
    }
    if (!fix_sample_ok) s_fix_have_prev = false;

    if (fix_sample_ok && fix_geom_steady && fix_pose_steady && fix_near) {
        const bool consistent = fabsf(fix_sample_y - s_fix_y) <= kAimFixLearnMax &&
                                fabsf(fix_sample_p - s_fix_p) <= kAimFixLearnMax;
        if (consistent) {
            s_fix_y += fminf(fmaxf(fix_sample_y - s_fix_y, -kAimFixRateDeg), kAimFixRateDeg);
            s_fix_p += fminf(fmaxf(fix_sample_p - s_fix_p, -kAimFixRateDeg), kAimFixRateDeg);
            s_fix_reject = 0;
        } else if (++s_fix_reject > kAimFixRejectFrames) {
            // Геометрия в покое и у цели, а поправка устойчиво другая — значит
            // сменилось орудие/раскладка: тянем трим медленно, без рывков.
            s_fix_y += fminf(fmaxf(fix_sample_y - s_fix_y, -kAimFixPullDeg), kAimFixPullDeg);
            s_fix_p += fminf(fmaxf(fix_sample_p - s_fix_p, -kAimFixPullDeg), kAimFixPullDeg);
        }
    } else {
        s_fix_reject = 0;
    }
    // Трим отдаём всегда (0 — ещё ничего не выучено): это постоянная состояния,
    // а не разовый отсчёт. Поправка идёт в те же yaw/pitch, по которым контроллер
    // ведёт камеру: для него это по-прежнему «одна ошибка наведения».
    const bool aim_fix_valid = true;
    const float aim_fix_yaw = s_fix_y, aim_fix_pitch = s_fix_p;
    const float yaw_fix   = aim_fix_yaw;
    const float pitch_fix = aim_fix_pitch;

    const float yaw   = yaw_cam + yaw_fix;
    const float pitch = pitch_cam + pitch_fix;

    // ---- Точка подхода -------------------------------------------------------
    // Встаём ПЕРЕД КРЕСТИКОМ (standoff наружу от оси узла) всегда, когда он
    // есть: удар теперь идёт наведением по X, а луч из-за ствола/породы до
    // обратной стороны не достаёт — с нашей стороны он упрётся в дерево и
    // ляжет в 0.2-0.6 м от крестика, то есть серия не вырастет. Крестик с
    // обратной стороны обходим (маневры обхода на подходе разворачивают бота
    // вокруг узла). Без крестика — просто перед узлом.
    Vec3 goal = best->pos;
    if (at_spot) {
        float ox = spot.x - best->pos.x, oz = spot.z - best->pos.z;
        float ol = sqrtf(ox * ox + oz * oz);
        if (ol < 0.05F) {   // X почти над пивотом — заходим со стороны игрока
            ox = g_frame_local_pos.x - best->pos.x;
            oz = g_frame_local_pos.z - best->pos.z;
            ol = sqrtf(ox * ox + oz * oz);
        }
        if (ol > 0.05F) {
            const float standoff = (best->kind == 0) ? 0.45F : 0.95F;
            goal.x = spot.x + (ox / ol) * standoff;
            goal.z = spot.z + (oz / ol) * standoff;
            goal.y = spot.y;
        }
    }
    float walk_yaw = 0.0F, walk_dist = best_dist;
    {
        const float gx = goal.x - origin.x, gz = goal.z - origin.z;
        const float gd = sqrtf(gx * gx + gz * gz);
        if (std::isfinite(gd)) {
            walk_dist = gd;
            const float gyaw = atan2f(gx * right.x + gz * right.z,
                                      gx * fwd.x + gz * fwd.z) * rad2deg;
            if (std::isfinite(gyaw)) walk_yaw = gyaw;
        }
    }

    // ---- Экранная метка: ровно та точка, по которой бьёт бот ----------------
    if (g_frame_vp_valid) {
        Vec2 screen{};
        if (w2s(g_frame_vp, aim, g_frame_sw, g_frame_sh, screen, false) &&
            std::isfinite(screen.x) && std::isfinite(screen.y) &&
            screen.x >= -64.0F && screen.x <= g_frame_sw + 64.0F &&
            screen.y >= -64.0F && screen.y <= g_frame_sh + 64.0F) {
            out.on_screen = true;
            out.sx = screen.x;
            out.sy = screen.y;
        }
    }

    const float adx = aim.x - g_frame_local_pos.x;
    const float adz = aim.z - g_frame_local_pos.z;
    const float aim_dist = sqrtf(adx * adx + adz * adz);
    // 3D-дистанция от ТОЙ ЖЕ точки, от которой считаем углы (глаз / ось
    // выстрела): именно её игра сравнивает с m_MaxReach + hitRadius в
    // FPMelee.ZkX, решая засчитать удар или сыграть промах. От
    // g_frame_local_pos (корень игрока) её мерить нельзя: глаз выше примерно
    // на 1.5 м, а вся дальность удара — пара метров.
    const float edx = aim.x - origin.x, edy = aim.y - origin.y, edz = aim.z - origin.z;
    const float aim_3d = sqrtf(edx * edx + edy * edy + edz * edz);

    g_farm_idle_reason = 0;
    out.valid = true;
    out.id = best->identity;
    out.ext_found = (node.ext_kind != FARM_EXT_NONE);
    out.kind = best->kind;
    out.yaw = yaw;
    out.pitch = pitch;
    out.aim_dist = std::isfinite(aim_dist) ? aim_dist : best_dist;
    out.aim_3d = std::isfinite(aim_3d) ? aim_3d : out.aim_dist;
    out.aim_x = aim.x; out.aim_y = aim.y; out.aim_z = aim.z;
    out.node_x = best->pos.x; out.node_y = best->pos.y; out.node_z = best->pos.z;
    // Дальность удара текущего орудия — из игры (FPMelee.m_MaxReach +
    // hitRadius), а не «на глаз». Ноль значит «в руках не ближнее орудие или
    // чтение не удалось» — тогда контроллер остаётся на эмпирических порогах.
    if (reach.valid) {
        out.melee_reach = reach.total;
        out.melee_ray = reach.ray_length;
        out.tool_purposes = reach.purposes_valid ? reach.tool_purposes : 0;
        if (reach.time_between_attacks > 0.0F)
            out.attack_period = reach.time_between_attacks + reach.pause_after_attack;
        // Перекрыт ли узел: луч игры упёрся заметно раньше нашей точки
        // прицела. Полметра допуска — на разницу между камерой и осью
        // выстрела (качание/отдача) и на то, что X стоит на поверхности меша.
        out.ray_valid = reach.ray_valid;
        out.ray_distance = reach.ray_distance;
        out.ray_blocked = reach.ray_valid && reach.ray_hit_object &&
                          reach.ray_distance > 0.0F &&
                          reach.ray_distance < out.aim_3d - 0.6F;
        // Вердикт «луч в нашем узле» посчитан в начале функции (ray_on_node).
        // Луч, упёршийся в собственный узел, перекрытием не считается: у камня
        // точка прицела внутри породы, и иначе бот вечно обходил бы свой же
        // камень (см. ray_hit_is_self_node). В out.ray_self_why остаётся, какая
        // именно проверка это доказала (1 коллайдер крестика, 2 GameObject узла,
        // 3 попадание в деталь поддерева) — по ней в логе видно, работает ли
        // послабление и почему нет.
        out.ray_self = ray_on_node;
        if (out.ray_self) {
            out.ray_self_why = ray_self_why;
            out.ray_blocked = false;
        }
        if (out.ray_blocked) {
            // Distance alone never proves ownership: nearby buildings are also inside reach.
            // Якорь точки удара (MineableObject.LXX) — замер для лога: если его
            // мировая позиция совпадает с точкой попадания луча, это готовая
            // точка прицела на поверхности камня ещё до первого удара.
            if (node.kind != 0) {
                Vec3 anchor{};
                float to_ray = -1.0F;
                int   valid = 0;
                if (farm_ore_anchor_point(node, anchor, to_ray, valid)) {
                    out.ore_anchor_valid = true;
                    out.ore_anchor_x = anchor.x; out.ore_anchor_y = anchor.y;
                    out.ore_anchor_z = anchor.z;
                    if (reach.ray_point_valid) {
                        const float dx = anchor.x - reach.ray_point.x;
                        const float dy = anchor.y - reach.ray_point.y;
                        const float dz = anchor.z - reach.ray_point.z;
                        out.ore_anchor_to_ray = sqrtf(dx * dx + dy * dy + dz * dz);
                    }
                }
            }
        }
        // (Прямой луч, попавший в узел, уже покрыт вердиктом ray_on_node:
        // отдельная перепроверка ниже больше не нужна.)
        // Постороннее попадание: луч игры упёрся в объект, который не наш
        // узел, — БЕЗ учёта дистанции. Именно это и есть «бот упёрся в
        // постройку и начал её ломать»: раньше замах блокировался, только
        // если чужой объект стоял ближе точки прицела на 0.6 м, а упёршись
        // в стену носом (луч в стене на любой дистанции) бот продолжал
        // махать. Теперь любая чужая геометрия на линии удара запрещает
        // замах, а контроллер обходит её или сдаёт узел.
        out.ray_foreign = reach.ray_valid && reach.ray_hit_object && !out.ray_self;
        // Обёртки GuI<GKo> — живой луч прицела игры (GKo.RaycastHit.m_Point):
        // точка, куда падает удар. По ней видно, попал ли замах в узел и
        // насколько точка попадания ушла от крестика. Это чтение, не запись:
        // удар идёт штатно.
        out.ray_wrapper_primary = reach.ray_primary_wrapper;
        out.ray_wrapper_fallback = reach.ray_fallback_wrapper;
        out.ray_point_valid = reach.ray_point_valid;
        if (reach.ray_point_valid) {
            out.ray_px = reach.ray_point.x; out.ray_py = reach.ray_point.y;
            out.ray_pz = reach.ray_point.z;
            out.ray_nx = reach.ray_normal.x; out.ray_ny = reach.ray_normal.y;
            out.ray_nz = reach.ray_normal.z;
        }
    }
    // Состояние самого узла. Здоровье — самый тонкий признак того, что удары
    // доходят: fractionRemaining сдвигается на проценты, а m_CurrentHealth
    // падает уже от первого попадания.
    {
        float hp = 0.0F, hp_max = 0.0F;
        if (rd_exact(best->component + MINEABLE_CURRENT_HEALTH, hp) &&
            std::isfinite(hp) && hp >= 0.0F && hp < 1000000.0F)
            out.node_health = hp;
        if (rd_exact(best->component + MINEABLE_MAX_HEALTH, hp_max) &&
            std::isfinite(hp_max) && hp_max > 0.0F && hp_max < 1000000.0F)
            out.node_health_max = hp_max;
        int32_t xp = 0;
        if (rd_exact(best->component + MINEABLE_EXPERIENCE, xp) && xp >= 0 && xp < 1000000)
            out.node_experience = (int)xp;
    }
    out.at_spot = at_spot;
    out.has_spot = has_spot;
    out.look_spot = look_spot;
    out.aim_fix_valid = aim_fix_valid;
    out.aim_fix_yaw = aim_fix_yaw;
    out.aim_fix_pitch = aim_fix_pitch;
    out.spot_front = spot_front;
    out.spot_source = spot_source;
    out.streak = streak;
    out.spot_life = spot_life;
    out.walk_yaw = walk_yaw;
    out.walk_dist = walk_dist;
    out.node_dist = best_dist;
    const float fraction = rd<float>(best->component + MINEABLE_FRACTION);
    out.fraction = (std::isfinite(fraction) && fraction >= 0.0F && fraction <= 1.001F)
                 ? fraction : -1.0F;
    return true;
}
