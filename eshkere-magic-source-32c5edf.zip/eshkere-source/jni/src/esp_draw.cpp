#include "esp_draw.h"
#include "aim.h"                 // AIM_MODE_MEMORY
#include "main.h"              // displayInfo, native_window_screen_*
#include "app_state.h"         // g_state
#include "cfg.h"
#include "process.h"           // g_esp_attached
#include "ui_util.h"           // ColU32
#include "theme.h"              // C::U(C::Acc()) — подсветка цели аима на кольце
#include "game_offsets_active.h" // go_active::PLAYER_BOX_WIDTH_RATIO
#include "lang.h"                // lang::visual: подпись оружия
#include "esp_box_hold.h"        // состав боксов/маркеров на кадр
#include "overlay_geometry.h"
#include "armor_esp.h"
#include "media/armor_atlas.h"
#include "stb_image/stb_image.h"
#include <GLES3/gl3.h>
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstddef>
#include <time.h>

// Radius (px) of the aim FOV circle. Original logic: cfg::aim::fov is an
// angle against a fixed 60° reference (not the live camera FOV), so the circle
// stays put on screen when the player zooms in. 180° = whole screen.
float AimFovRadiusPx(float sw, float sh) {
    float fov = cfg::aim::fov;
    if (fov <= 0.f) return 0.f;
    if (fov >= 180.f) return sw + sh;
    float t = tanf(fov * 0.5f * (float)M_PI / 180.f) / tanf(30.f * (float)M_PI / 180.f);
    float r = t * (sh * 0.5f);
    if (!std::isfinite(r) || r > sw + sh) r = sw + sh;
    return r;
}

// One remote snapshot per frame, shared by the ESP overlay and the aimbot.
// Сколько боксов нарисовано в последнем кадре — для сводки в мини-логе.

// One short hold window for every ESP visual, including world-marker labels.
constexpr double kEspHoldSeconds = 0.30;
// Окно пропуска на ЗДОРОВОМ кадре: один-два кадра чтения игрока могут не
// пройти, и бокс не должен гаснуть на 16 мс. 80 мс — это 5 кадров при 60 к/с,
// дальше запись уже не «мерцание», а тень.
constexpr double kEspMissSeconds = 0.08;
static GLuint g_armor_atlas_texture = 0;
static bool g_armor_atlas_attempted = false;

static void ensure_armor_atlas_texture() {
    if (g_armor_atlas_attempted) return;
    g_armor_atlas_attempted = true;
    int w = 0, h = 0, channels = 0;
    unsigned char* rgba = stbi_load_from_memory(kArmorAtlasPng,
        static_cast<int>(kArmorAtlasPngLen), &w, &h, &channels, 4);
    if (!rgba || w != kArmorAtlasCell * kArmorAtlasCols ||
        h != kArmorAtlasCell * kArmorAtlasRows) {
        if (rgba) stbi_image_free(rgba);
        return;
    }
    glGenTextures(1, &g_armor_atlas_texture);
    glBindTexture(GL_TEXTURE_2D, g_armor_atlas_texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                 GL_UNSIGNED_BYTE, rgba);
    stbi_image_free(rgba);
}

// Монотонное время в секундах — одно на кадр (и для холда, и для замеров).
static double mono_now() {
    timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

const std::vector<EspBox>& FrameBoxes(float sw, float sh) {
    static std::vector<espboxhold::Entry<EspBox>> s_hold;
    static std::vector<EspBox> s_out;
    static int s_frame = -1;
    static int s_sw = 0, s_sh = 0;
    const int frame = ImGui::GetFrameCount();
    const int want_w = (int)sw, want_h = (int)sh;
    // Ключ кэша — кадр И размеры экрана. Зовут его три разных места: ESP
    // (геометрия оверлея), аим (native_window_screen_*) и пилюля ХУДа
    // (VisibleScreen). Раньше ключом был только номер кадра, поэтому размеры
    // задавал ПЕРВЫЙ вызвавший, а остальные получали чужую проекцию — боксы
    // уезжали мимо модели. Сходится размер — отдаём готовое; разошёлся —
    // пересчитываем кадр под него (редкий случай, обычно все три зовут с одной
    // и той же landscape-парой).
    if (frame != s_frame || want_w != s_sw || want_h != s_sh) {
        const bool new_frame = frame != s_frame;
        s_frame = frame;
        s_sw = want_w; s_sh = want_h;
        if (!new_frame) {
            espboxhold::update(s_hold, esp_get_boxes(want_w, want_h),
                               esp_box_frame_transient(), mono_now(),
                               kEspHoldSeconds, kEspMissSeconds,
                               [](EspBox& box) { return esp_box_reproject(box); }, s_out);
            return s_out;
        }
        esp_set_skeleton_enabled(g_state.esp_skeleton);
        // Пеленги 360° стоят слойу памяти лишних чтений (группа игрока, флаг
        // respawn у тех, кто отсеян по экрану), поэтому они нужны ровно пока
        // рисуются стрелки.
        esp_set_bearings_enabled(g_state.esp_arrows || g_state.esp_radar);
        // Кости нужны аиму в обоих режимах: и касание, и память считают ошибку
        // по точке на шее, взятой из костей. Раньше запрос включался только от
        // касания, и в режиме «память» при выключенном скелете в ESP кости не
        // читались вовсе — тогда аим уходил на запасной расчёт по росту, а
        // признак смерти по позе вообще нечем было мерить.
        esp_set_aim_bones_enabled(g_state.aim_touch || g_state.aim_mode == AIM_MODE_MEMORY);
        // «Руда» считается включённой, только если включён хотя бы один тип:
        // иначе ни список меток, ни их скан не нужны вовсе.
        const bool ore_any = g_state.esp_ore &&
            (g_state.esp_ore_stone || g_state.esp_ore_iron || g_state.esp_ore_sulfur);
        esp_set_ore_types_enabled(g_state.esp_ore_stone, g_state.esp_ore_iron,
                                  g_state.esp_ore_sulfur);
        esp_set_markers_enabled(ore_any, g_state.esp_animal,
                                g_state.esp_loot, g_state.esp_pickup,
                                g_state.esp_vehicles, g_state.esp_bots,
                                g_state.esp_scrap, g_state.esp_turrets,
                                g_state.esp_backpacks, g_state.esp_sleepers,
                                g_state.esp_house_boxes, g_state.esp_cupboards,
                                g_state.esp_pumpkins);
        // Аим по ботам — тем же условием, что кости для аима: работает и
        // когда маркеры ботов выключены.
        esp_set_bot_aim_enabled(g_state.esp_bots || g_state.aim_touch ||
                                g_state.aim_mode == AIM_MODE_MEMORY);
        esp_set_always_day(g_state.always_day);
        esp_set_no_grass(g_state.no_grass);
        esp_set_marker_max_distance(g_state.marker_dist);
        // Контурная задержка и flight time считаются в game.cpp из таймнгов
        // Mirror и данных оружия; отдельного «упреждения» тут нет.
        esp_set_screen_stretch(g_state.screen_stretch_x);
        esp_set_xray(g_state.xray_on ? g_state.xray_range : 0.f);
        std::vector<EspBox> next = esp_get_boxes(want_w, want_h);
        const double now = mono_now();
        const bool transient = esp_box_frame_transient();
        const size_t raw_count = next.size();

        // Продление — только по мировому якорю: esp_box_reproject считает
        // экран заново текущей матрицей вида. Кадра без матрицы нет — записи
        // нет: приклеенный к экрану бокс хуже одной пропавшей.
        espboxhold::update(s_hold, next, transient, now, kEspHoldSeconds, kEspMissSeconds,
                           [](EspBox& box) { return esp_box_reproject(box); }, s_out);

        static double diag_at = -1e9;
        static int diag_frames = 0, diag_transient = 0;
        static size_t diag_raw_min = (size_t)-1, diag_raw_max = 0;
        static size_t diag_draw_min = (size_t)-1, diag_draw_max = 0;
        static int diag_hold_max = 0;
        ++diag_frames;
        if (transient) ++diag_transient;
        diag_raw_min = std::min(diag_raw_min, raw_count);
        diag_raw_max = std::max(diag_raw_max, raw_count);
        diag_draw_min = std::min(diag_draw_min, s_out.size());
        diag_draw_max = std::max(diag_draw_max, s_out.size());
        if (s_out.size() > raw_count)
            diag_hold_max = std::max(diag_hold_max, (int)(s_out.size() - raw_count));
        if (now - diag_at >= 1.0) {
            diag_at = now; diag_frames = diag_transient = 0;
            diag_raw_min = diag_draw_min = (size_t)-1;
            diag_raw_max = diag_draw_max = 0;
            diag_hold_max = 0;
        }
    }
    return s_out;
}

static const std::vector<EspMarker>& FrameMarkers() {
    static std::vector<espboxhold::Entry<EspMarker>> hold;
    static std::vector<EspMarker> out;
    static int cached_frame = -1;
    const int frame = ImGui::GetFrameCount();
    if (frame == cached_frame) return out;
    cached_frame = frame;

    std::vector<EspMarker> next = esp_get_markers();
    const double now = mono_now();
    espboxhold::erase_if(hold, [](const EspMarker& marker) {
        return marker.kind == ESP_MARKER_BOT && esp_marker_confirmed_dead(marker.id);
    });
    next.erase(std::remove_if(next.begin(), next.end(), [](const EspMarker& marker) {
        return marker.kind == ESP_MARKER_BOT && esp_marker_confirmed_dead(marker.id);
    }), next.end());
    // Метка тоже продлевается мировым якорем и перепроецируется текущей
    // камерой: повтор прошлых экранных координат приклеил бы её к экрану.
    espboxhold::update(hold, next, esp_marker_frame_transient(),
                       now, kEspHoldSeconds, kEspMissSeconds,
                       [](EspMarker& marker) { return esp_marker_reproject(marker); }, out);
    return out;
}

void DrawEspOverlay() {
    const OverlayGeometry overlay = MakeOverlayGeometry(
        displayInfo.width, displayInfo.height,
        native_window_screen_x, native_window_screen_y);
    const float sw = static_cast<float>(overlay.scene_width);
    const float sh = static_cast<float>(overlay.scene_height);
    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    if (!g_esp_attached) return;
    if (g_state.esp_armor) ensure_armor_atlas_texture();

    if (g_state.aim_touch && g_state.aim_special) {
        float fovR = AimFovRadiusPx(sw, sh);
        if (fovR > 1.f) {
            ImVec4 fc = cfg::aim::fov_col;
            dl->AddCircle(ImVec2(sw * 0.5f, sh * 0.5f), fovR,
                          ImGui::ColorConvertFloat4ToU32(fc), 72, 1.5f);
        }
    }

    // Список обязан совпадать с тем, что ниже рисуется: шкафы (esp_cupboards)
    // в нём отсутствовали, и с одним включённым тумблером «Шкафы» функция
    // выходила здесь — тумблер не делал ничего, пока не включишь ещё и горшки.
    if (!g_state.esp_box && !g_state.esp_chams && !g_state.esp_wall && !g_state.esp_tracer && !g_state.esp_skeleton && !g_state.esp_name && !g_state.esp_weapon && !g_state.esp_ore && !g_state.esp_animal && !g_state.esp_loot && !g_state.esp_pickup && !g_state.esp_bots && !g_state.esp_vehicles && !g_state.esp_scrap && !g_state.esp_turrets && !g_state.esp_backpacks && !g_state.esp_sleepers && !g_state.esp_house_boxes && !g_state.esp_cupboards && !g_state.esp_pumpkins && !g_state.esp_arrows && !g_state.esp_radar) return;

    const std::vector<EspBox>& boxes = FrameBoxes(sw, sh);
    constexpr int BOX_EDGES[][2] = {
        {0,1},{1,2},{2,3},{3,0},
        {4,5},{5,6},{6,7},{7,4},
        {0,4},{1,5},{2,6},{3,7}
    };
    float thick = g_state.esp_thick;
    if (thick < 0.5f) thick = 0.5f;

    // Thin dark-gray outline used across all visuals (no bold black strokes).
    const ImU32 kVisOutline = IM_COL32(45, 45, 52, 220);

    // ESP labels in the GUI style: compact rounded pill (light translucent fill
    // + thin gray outline) + colored text. The text is drawn with the same font
    // and size it is measured at (espFont/espFs) so it never spills out of the
    // pill — the old call drew at the full-size font while sizing at 0.8×, which
    // made the distance/weapon text overflow the pill.
    ImFont* espFont = ImGui::GetFont();
    float espFs = ImGui::GetFontSize() * 0.8f;
    auto PillH = [&](const char* text, float scale = 1.f) {
        if (!text || !text[0]) return 0.f;
        ImVec2 tsz = espFont->CalcTextSizeA(espFs * scale, FLT_MAX, 0, text);
        return tsz.y + 4.f * scale;
    };
    auto EspPill = [&](float cx, float y, const char* text, ImU32 textCol, float scale = 1.f) {
        if (!text || !text[0]) return;
        float fsz = espFs * scale;
        ImVec2 tsz = espFont->CalcTextSizeA(fsz, FLT_MAX, 0, text);
        const float padX = 5.f * scale, padY = 2.f * scale;
        float x0 = cx - tsz.x * 0.5f - padX;
        float x1 = cx + tsz.x * 0.5f + padX;
        float y1 = y + tsz.y + padY * 2.f;
        // Light translucent fill (not a dense black block), same for the name,
        // weapon and distance pills so they read consistently over any scene.
        dl->AddRectFilled(ImVec2(x0, y), ImVec2(x1, y1), IM_COL32(30, 30, 36, 40), 5.f * scale);
        dl->AddRect(ImVec2(x0, y), ImVec2(x1, y1), kVisOutline, 5.f * scale, 0, 1.0f);
        dl->AddText(espFont, fsz, ImVec2(cx - tsz.x * 0.5f, y + padY), textCol, text);
    };

    // A far away player projects to a couple of pixels, which used to make the
    // box degenerate (corners gone, top/bottom strokes fused into one line).
    // Every visual therefore works on a rect that is grown around its own
    // centre up to a stroke-aware minimum.
    //
    // The growth is a single uniform scale, not a per-axis clamp: clamping the
    // axes separately pushed the width of a distant player up to the same
    // minimum as the height and the box turned into a square. Scaling keeps the
    // player's proportions, so a far away box stays a small tall rectangle.
    const float kMinBoxSide = 3.0f * (thick + 1.0f) + 8.0f;      // vertical floor
    const float kMinBoxWidth = 2.0f * 1.5f + (thick + 1.5f);     // 2 stubs + a gap
    auto NormRect = [&](float& x1, float& y1, float& x2, float& y2) {
        if (x2 < x1) { float t = x1; x1 = x2; x2 = t; }
        if (y2 < y1) { float t = y1; y1 = y2; y2 = t; }
        float cx = (x1 + x2) * 0.5f, cy = (y1 + y2) * 0.5f;
        float w = x2 - x1, h = y2 - y1;
        if (!(h > 0.01f)) { h = kMinBoxSide; w = kMinBoxSide * go_active::PLAYER_BOX_WIDTH_RATIO; }
        if (h < kMinBoxSide) { float s = kMinBoxSide / h; h *= s; w *= s; }
        if (w < kMinBoxWidth) w = kMinBoxWidth; // only for absurdly narrow rects
        x1 = cx - w * 0.5f; x2 = cx + w * 0.5f;
        y1 = cy - h * 0.5f; y2 = cy + h * 0.5f;
    };
    // Corner box: the middle of every edge is cut out, only corners remain.
    // The corner length is capped per axis so the two segments of one edge can
    // never meet — at any distance a visible gap stays in the middle of the
    // top/bottom (and left/right) edges, which is what makes it read as a
    // corner box instead of a plain rectangle or a single fused line.
    auto CornerBox = [&](float x1, float y1, float x2, float y2, ImU32 col) {
        if (!std::isfinite(x1) || !std::isfinite(y1) || !std::isfinite(x2) || !std::isfinite(y2)) return;
        NormRect(x1, y1, x2, y2);
        float w = x2 - x1, h = y2 - y1;

        float len = (w < h ? w : h) * 0.28f;
        if (len > 42.f) len = 42.f;

        // Keep at least ~30% of every edge (and never less than one stroke
        // plus a pixel) empty in its middle.
        float gapX = w * 0.30f; if (gapX < thick + 1.5f) gapX = thick + 1.5f;
        float gapY = h * 0.30f; if (gapY < thick + 1.5f) gapY = thick + 1.5f;
        float lx = (w - gapX) * 0.5f; if (lx > len) lx = len;
        float ly = (h - gapY) * 0.5f; if (ly > len) ly = len;
        if (lx < 1.5f) lx = 1.5f;
        if (ly < 1.5f) ly = 1.5f;

        const ImVec2 pts[8][2] = {
            {{x1, y1}, {x1 + lx, y1}}, {{x1, y1}, {x1, y1 + ly}},
            {{x2 - lx, y1}, {x2, y1}}, {{x2, y1}, {x2, y1 + ly}},
            {{x1, y2 - ly}, {x1, y2}}, {{x1, y2}, {x1 + lx, y2}},
            {{x2 - lx, y2}, {x2, y2}}, {{x2, y2 - ly}, {x2, y2}},
        };
        for (int i = 0; i < 8; ++i)
            dl->AddLine(pts[i][0], pts[i][1], kVisOutline, thick + 1.0f);
        for (int i = 0; i < 8; ++i)
            dl->AddLine(pts[i][0], pts[i][1], col, thick);
    };

    for (const EspBox& box : boxes) {
        if (!std::isfinite(box.x1) || !std::isfinite(box.y1) || !std::isfinite(box.x2) || !std::isfinite(box.y2)) continue;
        if (box.is_bot) continue; // ботов рисуют маркеры, бокс — только данные для аима

        // Rect every visual (box, tracer, labels) is anchored to: never smaller
        // than the stroke-aware minimum, so nothing collapses at long range.
        float bx1 = box.x1, by1 = box.y1, bx2 = box.x2, by2 = box.y2;
        NormRect(bx1, by1, bx2, by2);

        // Союзники: выключатель «Союзники» в визуалах. Выключен — на союзнике
        // не рисуется НИЧЕГО: ни бокс, ни скелет, ни линия, ни ник, ни оружие.
        // Раньше признак своего влиял только на цвет, и убрать союзников с
        // экрана было нечем (просьба 19.09).
        if (box.ally && !g_state.esp_team) continue;
        // Team mates / clan mates get their own colour so they read as
        // friendly at a glance (and the aimbot leaves them alone).
        const bool ally = box.ally;

        if (g_state.esp_armor && g_armor_atlas_texture) {
            const float boxH = by2 - by1;
            float iconSize = ImMin(48.f, ImMax(12.f, boxH * 0.23f));
            float gap = (boxH - 4.f * iconSize) / 3.f;
            if (gap < 1.f) {
                gap = 1.f;
                iconSize = ImMax(10.f, (boxH - 3.f) * 0.25f);
            }
            const float x = bx1 - iconSize - 4.f;
            for (int slot = 0; slot < 4; ++slot) {
                const unsigned icon = box.armor_icons[slot];
                if (!armoresp::valid_icon(icon)) continue;
                const int col = static_cast<int>(icon) % kArmorAtlasCols;
                const int row = static_cast<int>(icon) / kArmorAtlasCols;
                const ImVec2 p0{x, by1 + slot * (iconSize + gap)};
                const ImVec2 p1{p0.x + iconSize, p0.y + iconSize};
                const ImVec2 uv0{(float)(col * kArmorAtlasCell) /
                                    (kArmorAtlasCell * kArmorAtlasCols),
                                (float)(row * kArmorAtlasCell) /
                                    (kArmorAtlasCell * kArmorAtlasRows)};
                const ImVec2 uv1{uv0.x + 1.f / kArmorAtlasCols,
                                 uv0.y + 1.f / kArmorAtlasRows};
                dl->AddRectFilled(p0, p1, IM_COL32(12, 14, 20, 205), 3.f);
                dl->AddImageRounded((ImTextureID)(intptr_t)g_armor_atlas_texture,
                                    p0, p1, uv0, uv1, IM_COL32_WHITE, 3.f);
                dl->AddRect(p0, p1, IM_COL32(255, 255, 255, 90), 3.f, 0, 1.f);
            }
        }

        if (g_state.esp_chams) {
            bool all_valid = true;
            for (int c = 0; c < 8; ++c) {
                if (!box.corner_visible[c] || !std::isfinite(box.corners[c][0]) || !std::isfinite(box.corners[c][1]) || box.corners[c][0] < 0 || box.corners[c][1] < 0) {
                    all_valid = false;
                    break;
                }
            }
            if (all_valid) {
                ImU32 col = ColU32(cfg::esp::box_col_invis);
                // 3D box edges collapse to a single line at long range because the
                // projected top/bottom (and left/right) faces sit within a pixel or
                // two. Measure the on-screen extent and, when it is below a stroke
                // aware minimum, draw a flat, centred box with that minimum span so
                // the horizontal rows stay visibly separated (same guarantee as the
                // corner box) instead of fusing into one line.
                float mnX = FLT_MAX, mnY = FLT_MAX, mxX = -FLT_MAX, mxY = -FLT_MAX;
                for (int c = 0; c < 8; ++c) {
                    float x = box.corners[c][0], y = box.corners[c][1];
                    if (x < mnX) mnX = x;
                    if (x > mxX) mxX = x;
                    if (y < mnY) mnY = y;
                    if (y > mxY) mxY = y;
                }
                float dMin = kMinBoxSide;
                if ((mxX - mnX) >= dMin && (mxY - mnY) >= dMin) {
                    for (const auto& edge : BOX_EDGES) {
                        int a = edge[0], b = edge[1];
                        dl->AddLine(
                            ImVec2(box.corners[a][0], box.corners[a][1]),
                            ImVec2(box.corners[b][0], box.corners[b][1]),
                            col, thick
                        );
                    }
                } else {
                    dl->AddRect(ImVec2(bx1, by1), ImVec2(bx2, by2), kVisOutline, 0.f, 0, thick + 1.0f);
                    dl->AddRect(ImVec2(bx1, by1), ImVec2(bx2, by2), col, 0.f, 0, thick);
                }
            }
        }

        if (g_state.esp_box) {
            // Дыхание рамки захваченной цели (см. aim.h): пока аим ДЕРЖИТ эту
            // цель (hold свежий — без цели выбор не тикает и затухает за
            // 0.2 с), уголки крутят непрерывный цикл «вдох»: пружинный разлёт
            // на ~3.5 px за 1.0 с и возврат резинкой 1.0 с (скольжение к
            // концу, ease-out кубик), период 2.0 с — секунда на разлёт,
            // секунда на возврат (настройка по просьбе «разлёт 1 с, возврат 1 с»).
            float poff = 0.f;
            if (g_state.aim_touch && box.id != 0 &&
                box.id == g_aim_pulse_target.load(std::memory_order_relaxed)) {
                timespec pts{}; clock_gettime(CLOCK_MONOTONIC, &pts);
                const double now = (double)pts.tv_sec + (double)pts.tv_nsec * 1e-9;
                const double hold_age = now - g_aim_hold_at.load(std::memory_order_relaxed);
                if (hold_age >= 0.0 && hold_age <= 0.20) {
                    constexpr double kPeriod = 2.0, kOut = 1.0;
                    constexpr float kMax = 3.5f;   // разбег 0.35 px по просьбе (было 7.5)
                    double t = now - g_aim_pulse_at.load(std::memory_order_relaxed);
                    if (t < 0.0) t = 0.0;
                    double ph = t / kPeriod; ph = (ph - floor(ph)) * kPeriod;
                    if (ph <= kOut) {
                        const float u = (float)(ph / kOut);
                        poff = kMax * (1.f - (1.f - u) * (1.f - u));
                    } else {
                        const float u = (float)((ph - kOut) / (kPeriod - kOut));
                        poff = kMax * (1.f - u) * (1.f - u) * (1.f - u);
                    }
                }
            }
            const bool invis = cfg::esp::vis_check && !ally && !box.visible;
            CornerBox(bx1 - poff, by1 - poff, bx2 + poff, by2 + poff,
                      ColU32(ally ? cfg::esp::ally_col
                                  : (invis ? cfg::esp::box_col_invis : cfg::esp::box_col)));
        }

        if (g_state.esp_skeleton && box.has_skeleton) {
            ImU32 skelCol = ColU32((cfg::esp::vis_check && !ally && !box.visible)
                                   ? cfg::esp::box_col_invis
                                   : cfg::esp::skeleton_col);
            auto validPt = [&](int b) {
                return b >= 0 && box.bone_valid[b] &&
                       std::isfinite(box.bones[b][0]) && std::isfinite(box.bones[b][1]);
            };
            auto lineTo = [&](int a, int b) {
                dl->AddLine(ImVec2(box.bones[a][0], box.bones[a][1]),
                            ImVec2(box.bones[b][0], box.bones[b][1]),
                            skelCol, thick);
            };
            // Draw each chain connecting consecutive valid bones, skipping
            // missing ones (0..5 torso, 6..9/10..13 arms, 14..17/18..21 legs).
            auto drawChain = [&](const int* chain, int n, int anchor) {
                int prev = validPt(anchor) ? anchor : -1;
                for (int i = 0; i < n; ++i) {
                    int b = chain[i];
                    if (!validPt(b)) continue;
                    if (prev >= 0) lineTo(prev, b);
                    prev = b;
                }
            };
            // Arms hang off the highest available spine bone.
            int chest = -1;
            for (int c : {3, 2, 1, 0}) { if (validPt(c)) { chest = c; break; } }

            static const int torso[] = {1, 2, 3, 4, 5};
            static const int armL[]  = {6, 7, 8, 9};
            static const int armR[]  = {10, 11, 12, 13};
            static const int legL[]  = {14, 15, 16, 17};
            static const int legR[]  = {18, 19, 20, 21};
            drawChain(torso, 5, 0);
            drawChain(armL, 4, chest);
            drawChain(armR, 4, chest);
            drawChain(legL, 4, 0);
            drawChain(legR, 4, 0);
        }



        if (g_state.esp_tracer) {
            // From the middle of the top edge of the screen to the head area.
            // Team mates get a green line so a glance at the tracer is enough.
            float tx = (bx1 + bx2) * 0.5f;
            ImU32 tracerCol = ColU32(ally ? cfg::esp::ally_tracer_col : cfg::esp::tracer_col);
            dl->AddLine(ImVec2(sw * 0.5f, 0.0f), ImVec2(tx, by1),
                        kVisOutline, thick + 1.0f);
            dl->AddLine(ImVec2(sw * 0.5f, 0.0f), ImVec2(tx, by1), tracerCol, thick);
        }

        // Name above the box; distance right under the box, weapon under the
        // distance.
        {
            float cx = (bx1 + bx2) * 0.5f;
            const float gap = 5.f;
            if (g_state.esp_name && box.has_name && box.name[0]) {
                // Clan tag in front of the nick, the way the game shows it.
                char label[56];
                if (box.has_tag && box.tag[0])
                    snprintf(label, sizeof(label), "[%s] %s", box.tag, box.name);
                else
                    snprintf(label, sizeof(label), "%s", box.name);
                float h = PillH(label);
                EspPill(cx, by1 - h - gap, label,
                        ColU32(ally ? cfg::esp::ally_col : cfg::esp::name_col));
            }
            float belowY = by2 + gap;
            if (g_state.esp_wall) {
                char label[32];
                if (box.distance >= 0.0f) snprintf(label, sizeof(label), "%.1fm", box.distance);
                else snprintf(label, sizeof(label), "PLAYER");
                EspPill(cx, belowY, label, ColU32(cfg::esp::distance_col));
                belowY += PillH(label) + 4.f;
            }
            if (g_state.esp_weapon && box.has_weapon && box.weapon[0]) {
                // Короткие подписи из weapon_label_for_item_id («Дигл»,
                // «Самопал», ...) русские всегда — перевод здесь, в единственной
                // точке отрисовки. Английское и неизвестное lookup возвращает
                // как есть, так что остальным путям это не вредит.
                EspPill(cx, belowY, lang::visual(box.weapon), ColU32(cfg::esp::weapon_col));
                belowY += PillH(box.weapon) + 4.f;
            }
        }
    }

    // ---- World markers: ore, animals, bots, vehicles ---------------------
    // One pill with the resource / animal / bot / vehicle name at the object's
    // position; the scan itself is done by the game layer and reuses this
    // frame's camera.
    if (g_state.esp_ore || g_state.esp_animal || g_state.esp_loot || g_state.esp_pickup || g_state.esp_bots || g_state.esp_vehicles || g_state.esp_scrap || g_state.esp_turrets || g_state.esp_backpacks || g_state.esp_sleepers || g_state.esp_house_boxes || g_state.esp_cupboards || g_state.esp_pumpkins) {
        // Smaller than the player labels (there are many more of them), with the
        // distance on a second line underneath.
        constexpr float kMarkerScale = 0.78f;
        // Elite crates pulse through the spectrum: one hue for all of them per
        // frame (a full turn every two seconds) so they cannot be missed.
        const float rainbow_hue = fmodf((float)ImGui::GetTime() * 0.5f, 1.0f);
        float rr = 1.f, rg = 1.f, rb = 1.f;
        ImGui::ColorConvertHSVtoRGB(rainbow_hue, 0.85f, 1.0f, rr, rg, rb);
        const ImU32 rainbow_col = IM_COL32((int)(rr * 255.f), (int)(rg * 255.f), (int)(rb * 255.f), 255);
        // Маркеры — отдельная стадия: сканирование реестра и позиции сущностей
        // живут в FrameMarkers, и падение в них при stage=esp неотличимо от
        // падения в конвейере игроков.
        const std::vector<EspMarker>& frame_markers = FrameMarkers();
        for (const EspMarker& marker : frame_markers) {
            if (!marker.name[0]) continue;
            if (!std::isfinite(marker.x) || !std::isfinite(marker.y)) continue;
            ImU32 col = marker.rainbow ? rainbow_col
                : marker.has_color
                ? IM_COL32(marker.color_rgb[0], marker.color_rgb[1], marker.color_rgb[2], 255)
                : ColU32(marker.kind == ESP_MARKER_LOOT    ? cfg::esp::loot_col
                       : marker.kind == ESP_MARKER_SCRAP   ? cfg::esp::scrap_col
                       : marker.kind == ESP_MARKER_PICKUP  ? cfg::esp::pickup_col
                       : marker.kind == ESP_MARKER_BOT     ? cfg::esp::bot_col
                       : marker.kind == ESP_MARKER_VEHICLE ? cfg::esp::vehicle_col
                       : marker.kind == ESP_MARKER_TURRET   ? cfg::esp::turret_col
                       : marker.kind == ESP_MARKER_BACKPACK ? cfg::esp::backpack_col
                       : marker.kind == ESP_MARKER_SLEEPER  ? cfg::esp::sleeper_col
                       : marker.kind == ESP_MARKER_CUPBOARD ? cfg::esp::cupboard_col
                       : marker.kind == ESP_MARKER_PUMPKIN  ? cfg::esp::pumpkin_col
                       : marker.kind == ESP_MARKER_HOUSE    ? cfg::esp::loot_col
                                                           : cfg::esp::animal_col);
            EspPill(marker.x, marker.y, marker.name, col, kMarkerScale);
            char label[24];
            snprintf(label, sizeof(label), "%.0fm", marker.distance);
            EspPill(marker.x, marker.y + PillH(marker.name, kMarkerScale) + 2.f, label,
                    ColU32(cfg::esp::distance_col), kMarkerScale);
        }
    }

    // ---- Стрелки 360° ------------------------------------------------------
    // Кольцо вокруг центра экрана: по стрелке на противника, включая тех, кого
    // в кадре нет вовсе (за спиной, из-за угла). Источник — пеленги слоя памяти
    // (esp_get_bearings), угол компасный: 0 = прямо перед камерой, дальше по
    // часовой, ±180 за спиной.
    //
    // Именно кольцо, а не «прижатая к кромке точка проекции»: проецирование
    // отказывает, когда цель проходит за камерой (w <= 0), и у экранного
    // варианта стрелка прыгала бы с левого края на правый ровно в этот момент.
    // Компасный угол идёт непрерывно все 360°, поэтому обход за спиной — это
    // плавное движение по кругу. Наклон (pitch) не участвует намеренно: на
    // кольце «вверху» значит «впереди», а не «на крыше».
    // Цель, которую аим держит сейчас: подсвечивается акцентом и на кольце
    // стрелок, и на радаре. Окно холда — те же 0.2 с, что у «дыхания» рамки.
    unsigned long long held = 0;
    if (g_state.aim_touch && (g_state.esp_arrows || g_state.esp_radar)) {
        const double hold_age = mono_now() - g_aim_hold_at.load(std::memory_order_relaxed);
        if (hold_age >= 0.0 && hold_age <= 0.20)
            held = g_aim_pulse_target.load(std::memory_order_relaxed);
    }

    if (g_state.esp_arrows) {
        const std::vector<EspBearing>& bearings = esp_get_bearings();
        const float short_side = sw < sh ? sw : sh;
        float ring_pct = g_state.esp_arrow_ring;
        if (!(ring_pct >= 8.f && ring_pct <= 60.f)) ring_pct = 30.f;
        const float radius = short_side * 0.5f * (ring_pct * 0.01f);
        const float ccx = sw * 0.5f, ccy = sh * 0.5f;
        // Длина стрелки привязана к радиусу кольца: на маленьком кольце
        // соседние цели иначе слипались бы в одно пятно.
        const float size = radius * 0.16f;
        if (radius > 8.f && !bearings.empty()) {
            for (const EspBearing& b : bearings) {
                if (b.dead) continue;
                // Союзники на кольце — только когда включён их показ (тот же
                // тумблер, что у визуалов); мёртвых и выключенных ботов нет.
                if (b.ally && !g_state.esp_team) continue;
                if (b.is_bot && !g_state.esp_bots) continue;
                if (g_state.esp_arrows_offscreen && b.on_screen) continue;
                if (!std::isfinite(b.yaw)) continue;

                const float a = b.yaw * ((float)M_PI / 180.f);
                const float dx = sinf(a), dy = -cosf(a);   // наружу от центра
                const float px = -dy, py = dx;              // перпендикуляр
                const ImVec2 tip  = {ccx + dx * (radius + size), ccy + dy * (radius + size)};
                const ImVec2 base = {ccx + dx * (radius - size * 0.35f),
                                     ccy + dy * (radius - size * 0.35f)};
                const float half = size * 0.62f;
                const ImVec2 c1 = {base.x + px * half, base.y + py * half};
                const ImVec2 c2 = {base.x - px * half, base.y - py * half};

                ImU32 col = ColU32(b.ally ? cfg::esp::ally_col : cfg::esp::arrow_col);
                if (b.is_bot) col = ColU32(cfg::esp::bot_col);
                if (held != 0 && b.id == held) col = C::U(C::Acc());

                dl->AddTriangle(tip, c1, c2, kVisOutline, thick + 0.6f);
                dl->AddTriangleFilled(tip, c1, c2, col);

                if (g_state.esp_arrows_dist && b.distance >= 0.0f) {
                    char label[24];
                    snprintf(label, sizeof(label), "%.0fm", b.distance);
                    constexpr float kArrowScale = 0.8f;
                    const float h = PillH(label, kArrowScale);
                    // Подпись — продолжение луча стрелки; у краёв экрана её не
                    // режет: кольцо вместе с хвостом заведомо внутри короткой
                    // стороны (радиус клампится 60% половины стороны).
                    EspPill(ccx + dx * (radius + size * 2.6f),
                            ccy + dy * (radius + size * 2.6f) - h * 0.5f,
                            label, col, kArrowScale);
                }
            }
        }
    }

    // ---- Радар 360° в углу -------------------------------------------------
    // Те же пеленги, что у стрелок (esp_get_bearings), но точка лежит на круге
    // радара пропорционально дистанции: кольцу стрелок безразлично, кто в 5 м,
    // а кто в 90 — радар отвечает ровно на это. Верх = «передо мной», как на
    // кольце: один и тот же компасный угол на обоих визуалах, иначе они
    // расходились бы при каждом повороте камеры.
    if (g_state.esp_radar) {
        const std::vector<EspBearing>& bearings = esp_get_bearings();
        float size = g_state.esp_radar_size;
        if (!(size >= 90.f && size <= 360.f)) size = 170.f;
        float range = g_state.esp_radar_range;
        if (!(range >= 10.f && range <= 400.f)) range = 100.f;
        const float R = size * 0.5f;
        // Верхний правый угол: счётчик игроков живёт сверху по центру, органы
        // управления фрикама/FakeLag — по центру справа, радар их не закрывает.
        const float margin = 18.f;
        const ImVec2 rc = {sw - R - margin, R + margin};

        dl->AddCircleFilled(rc, R, IM_COL32(12, 14, 22, 150), 96);
        dl->AddCircle(rc, R, IM_COL32(255, 255, 255, 60), 96, 1.f);
        // Полукруг дальности + оси: по ним читается масштаб, а не только «кто».
        dl->AddCircle(rc, R * 0.5f, IM_COL32(255, 255, 255, 26), 64, 1.f);
        dl->AddLine(ImVec2(rc.x, rc.y - R), ImVec2(rc.x, rc.y + R), IM_COL32(255, 255, 255, 22), 1.f);
        dl->AddLine(ImVec2(rc.x - R, rc.y), ImVec2(rc.x + R, rc.y), IM_COL32(255, 255, 255, 22), 1.f);
        // Мы — в центре, и всегда: радар привязан к нам, а не к миру.
        dl->AddCircleFilled(rc, 2.8f, IM_COL32(255, 255, 255, 220), 12);

        for (const EspBearing& b : bearings) {
            if (b.dead) continue;
            if (b.ally && !g_state.esp_team) continue;
            if (b.is_bot && !g_state.esp_bots) continue;
            if (!std::isfinite(b.yaw)) continue;
            // Дальше дальности — к кромку, но не за неё: «там кто-то есть»
            // должно оставаться видимым, а не исчезать с радиуса.
            const float dist = b.distance >= 0.0f ? b.distance : range;
            const float frac = dist >= range ? 0.94f : (dist / range) * 0.94f;
            const float rr = R * frac;
            const float a = b.yaw * ((float)M_PI / 180.f);
            const ImVec2 p = {rc.x + sinf(a) * rr, rc.y - cosf(a) * rr};
            ImU32 col = ColU32(b.ally ? cfg::esp::ally_col : cfg::esp::box_col);
            if (b.is_bot) col = ColU32(cfg::esp::bot_col);
            if (held != 0 && b.id == held) col = C::U(C::Acc());
            const float dot = R * 0.028f + 1.6f;
            dl->AddCircleFilled(p, dot + 1.2f, kVisOutline, 12);
            dl->AddCircleFilled(p, dot, col, 10);
        }

        if (!bearings.empty()) {
            char label[24];
            snprintf(label, sizeof(label), "%.0fm", range);
            constexpr float kRadarScale = 0.72f;
            EspPill(rc.x, rc.y + R + 5.f, label, ColU32(cfg::esp::distance_col), kRadarScale);
        }
    }
}
