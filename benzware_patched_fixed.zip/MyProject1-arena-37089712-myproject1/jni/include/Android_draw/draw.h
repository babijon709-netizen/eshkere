#ifndef NATIVESURFACE_DRAW_H
#define NATIVESURFACE_DRAW_H

#include <iostream>
#include <thread>
#include <chrono>
#include <dlfcn.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstdio>
#include <cstring>
#include <cerrno>
#include <android/native_window.h>
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <GLES3/gl32.h>

#include "native_surface/ANativeWindowCreator.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_internal.h"
#include "ImGui/backends/imgui_impl_android.h"
#include "ImGui/backends/imgui_impl_opengl3.h"
#include "Android_touch/TouchHelperA.h"

using namespace std;
using namespace std::chrono_literals;

extern anwc::ANativeWindowCreator::DisplayInfo displayInfo;
extern bool g_Initialized;
extern ImGuiWindow *g_window;
extern int native_window_screen_x, native_window_screen_y;

bool init_egl(uint32_t _screen_x, uint32_t _screen_y, bool log = false);
bool initGUI_draw(uint32_t _screen_x, uint32_t _screen_y, bool log = false);
bool ImGui_init();
void screen_config();
void drawBegin();
void drawEnd();
void shutdown();
float overlay_fps();
// Темп оверлея и диагностика (см. kOverlayFallbackPaceHz в draw.cpp): из
// последнего кадра — сколько он проспал до своего темпа, сколько из этого
// пришлось на ожидание начала кадра игры (0 = фаза не поймана, шли по таймеру),
// пик панели и сам темп — для шапки лога.
double overlay_pace_sleep_ms();
double overlay_pace_tick_ms();
float overlay_peak_hz();
float overlay_pace_hz();

#endif